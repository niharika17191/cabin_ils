<!DOCTYPE html>

<?php
include '../mdbConnect.php';

//Get pids
$pids = file('/home/diana/AAA/log/pids.log', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
//Get partition names
$i = 0;
foreach($pids as $pid_num => $pid){
	$cmd = "ps -p ".$pid." -o comm=";
	$pname = shell_exec($cmd);
	if(!empty($pname)) {
		$ptable[$i][0] = $pid;
		$ptable[$i][1] = $pname;
		$i++;	
	}
}
$pCnt = $i;	
?>

<html>
<head>
<meta http-equiv="refresh" content="5" >
<style>
table, th, td {
    border: 1px solid black;
}
</style>

<?php
	echo "<title>".$modName.": WebSPY - Partitions</title>";	
?>
</head>

<body>
<h2>Partitioning</h2>
<?php include '../ownModInfo.php'; ?>

<h3>Partition Table</h3>

<table>
	<tr>
    <th>PID</th> <th>Name</th>
    <th>
		<form action="killAllPartitions.php" method="post">
			<button name="1" value="all">Kill All</button>
		</form>    
    </th>
	</tr>
	<?php
	for($i=0; $i < $pCnt; $i++) {
		echo "<tr>";		
		echo "<td>".$ptable[$i][0]."</td><td><b>".$ptable[$i][1]."</b></td>";
		echo "<td><form action=\"killPartition.php\" method=\"get\">";
		echo "<button name=\"pid\" value=\"".$ptable[$i][0]."\">Kill</button></form></td>";
		echo "</tr>";
		}	
	?>
</table>


</br>
<a href="../index.php">Home</a>
</body>

</html>