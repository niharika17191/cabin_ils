<!DOCTYPE html>

<?php
	include '../resMaFunctions.php';

	$pagenameShort = "blacklist history";
	$pagenameLong = "Opp modules blacklist history";
	
	//Connect to module DB
	$servername = "localhost";
	$username = "root";
	$password = "jagen";
	// Create connection
	$conn = new mysqli($servername, $username, $password);

	// Check connection
	if ($conn->connect_error) {
	   	die("Connection failed: " . $conn->connect_error);
	}

?>
<html>
<head>
<meta http-equiv="refresh" content="2" >
	<style>
		table, th, td {
			border: 1px solid black;
		}
	</style>
	<title>
		<?php echo gethostname() . " - " . $pagenameShort;?>
	</title>
</head>

<body>

<h1>Opp module blacklist History</h1>
	
	<?php
		include '../../ownModInfo.php';

		$abfrage = "SELECT * FROM plamaDB.xModuleConfig_history";
		$ergebnis = mysqli_query($conn, $abfrage);
		$row = mysqli_fetch_assoc($ergebnis);
		$t0=strtotime($row['dt_datetime']);

	?>
	</br>

	<table>
		<tr>
			<th>&Delta;T [sec]</th><th>Time</th><th>Name</th><th>Id</th><th>Blacklist State</th>

		</tr>
		<?php
			$abfrage = "SELECT s.dt_datetime, m.name, m.id, s.blacklistState FROM plamaDB.xModuleConfig_history AS s INNER JOIN orgDB.module AS m ON (s.module_id = m.id) ORDER BY s.dt_datetime";
			$ergebnis = mysqli_query($conn, $abfrage);
			
			while($row = mysqli_fetch_assoc($ergebnis)) {			
				
				if($row["blacklistState"]=="IS_PROCESS_MSG" OR $row["blacklistState"]=="IS_DROP_MSG"){			
					echo "<tr>";
					
						
						$dt= strtotime($row['dt_datetime'])-$t0;
						echo "<td>".$dt."</td>";
						echo "<td>".$row['dt_datetime']."</td>";
						echo "<td>".$row['name']."</td>";
						echo "<td>".$row['id']."</td>";
						echo showInputStateCell($row["blacklistState"]);
					echo "</tr>";
				}
			}


		?>   		

	</table>

	</br>
	</br>
	<a href="../resConfig.php">Ressource Configuration</a>
	</br>
	<a href="../../index.php">Home</a>

</body>

</html>


