<!DOCTYPE html>

<?php
	include '../resMaFunctions.php';

	$pagenameShort = "Switches";
	$pagenameLong = "Switch Mode history";
	
	//Connect to module DB
	$servername = "localhost";
	$username = "root";
	$password = "jagen";
	// Create connection
	$conn = new mysqli($servername, $username, $password);

	// Check connection
	if ($conn->connect_error) {
	   	die("Connection failed: " . $conn->connect_error);
	}

	$oppMod=$_GET["oppMod"];

?>
<html>
<head>
<meta http-equiv="refresh" content="2" >
	<style>
		table, th, td {
			border: 1px solid black;
		}
	</style>
	<title>
		<?php echo gethostname() . " - " . $pagenameShort;?>
	</title>
</head>

<body>

<h1>Switch Mode History</h1>
	
	<?php include '../../ownModInfo.php'; ?>

	<h3>Please Chose Parameters:</h3>
		

	<form action='switches.php' method='get'>
		Modul:<select name=oppMod>
			<option value='All'> All</option> 
			<?php
				$abfrage = "SELECT m.id, m.name FROM plamaDB.switchConfig s INNER JOIN orgDB.module m ON (s.module_id =m.id)";
				$ergebnis = mysqli_query($conn, $abfrage);

				while($row = mysqli_fetch_assoc($ergebnis)) {

					if($row["name"]==$oppMod){
			
						echo "<option value=".$row['name']." selected>".$row['name']."</option>";
					}
					else{

						echo "<option value=".$row['name'].">".$row['name']."</option>";
					}
			
				}
			?>
		</select>

		<input type='submit'>
	</form>
	<?php

		$abfrage = "SELECT * FROM plamaDB.switchConfig_history";
		$ergebnis = mysqli_query($conn, $abfrage);
		$row = mysqli_fetch_assoc($ergebnis);
		$t0=strtotime($row['dt_datetime']);

	?>
	</br>
	<table>
		<tr>
			<th>&Delta;T [sec]</th><th>Time</th><th>Name</th><th>Id</th><th colspan="2">Active Table</th>
		</tr>
		<?php
			if($oppMod=='All'){
				$abfrage = "SELECT s.dt_datetime, m.name AS mName, m.id, s.cmdId, r.name AS rName FROM plamaDB.switchConfig_history s INNER JOIN orgDB.module m ON (s.module_id = m.id) INNER JOIN plamaDB.routingTables r ON (s.routingTables_id = r.id) ORDER BY s.dt_datetime";
				$ergebnis = mysqli_query($conn, $abfrage);
					
				while($row = mysqli_fetch_assoc($ergebnis)) {			
							
					echo "<tr>";
					
						
						$dt= strtotime($row['dt_datetime'])-$t0;
						echo "<td>".$dt."</td>";
						echo "<td>".$row['dt_datetime']."</td>";						
						echo "<td>".$row['mName']."</td>";
						echo "<td>".$row['id']."</td>";
						echo showRTCell($row["rName"]);
					echo "</tr>";
				}
			}
			else{
				
				$abfrage = "SELECT s.dt_datetime, m.name AS mName, m.id, s.cmdId, r.name AS rName FROM plamaDB.switchConfig_history s INNER JOIN orgDB.module m ON (s.module_id = m.id) INNER JOIN plamaDB.routingTables r ON (s.routingTables_id = r.id) WHERE m.name = '".$oppMod."' ORDER BY s.dt_datetime";
				$ergebnis = mysqli_query($conn, $abfrage);
					
				while($row = mysqli_fetch_assoc($ergebnis)) {			
							
					echo "<tr>";
					
						
						$dt= strtotime($row['dt_datetime'])-$t0;
						echo "<td>".$dt."</td>";
						echo "<td>".$row['dt_datetime']."</td>";						
						echo "<td>".$row['mName']."</td>";
						echo "<td>".$row['id']."</td>";
						echo "<td>".$row['cmdId']."</td>";
						echo showRTCell($row["rName"]);
					echo "</tr>";
				}
			}

		?>   		

	</table>

	
	</br>
	</br>
	<a href="../resConfig.php">Ressource Configuration</a>
	</br>
	<a href="../../index.php">Home</a>

</body>

</html>

