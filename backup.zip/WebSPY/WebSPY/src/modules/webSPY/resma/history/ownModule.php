<!DOCTYPE html>

<?php
	include '../resMaFunctions.php';

	$pagenameShort = "OwnMo";
	$pagenameLong = "Own Module history";
	
	//Connect to module DB
	$servername = "localhost";
	$username = "root";
	$password = "jagen";
	// Create connection
	$conn = new mysqli($servername, $username, $password);

	// Check connection
	if ($conn->connect_error) {
	   	die("Connection failed: " . $conn->connect_error);
	}

?>
<html>
<head>
<meta http-equiv="refresh" content="2" >
	<style>
		table, th, td {
			border: 1px solid black;
		}
	</style>
	<title>
		<?php echo gethostname() . " - " . $pagenameShort;?>
	</title>
</head>

<body>
	
	<h1>Own Module History</h1>
	
	<?php 
		include '../../ownModInfo.php';
		
		$abfrage = "SELECT * FROM plamaDB.ownOwnEval_history";
		$ergebnis = mysqli_query($conn, $abfrage);
		$row = mysqli_fetch_assoc($ergebnis);
		$t0=strtotime($row['dt_datetime']);

	?>
	
	</br>
	
	<table>
		<tr>
			<th>&Delta;T [sec]</th><th>Time</th><th>Module</th><th>Own -> Own</th><th>Opmo</th>
		</tr>
		<?php
			$abfrage = "SELECT * FROM plamaDB.ownOwnEval_history";
			$ergebnis = mysqli_query($conn, $abfrage);
					
			while($row = mysqli_fetch_assoc($ergebnis)) {			
							
				echo "<tr>";		
					$dt= strtotime($row['dt_datetime'])-$t0;
					echo "<td>".$dt."</td>";
					echo "<td>".$row['dt_datetime']."</td>";
					if($row['action']=="update modGM"){
						echo showGMCell($row["modGM"]) ;
						echo "<td>".$row["ownOwnGM"]."</td>";
						echo "<td>".$row["modOpmo"]."</td>";
					}
					else if($row['action']=="update ownGM"){
						echo "<td>".$row["modGM"]."</td>";
						echo showGMCell($row["ownOwnGM"]);
						echo "<td>".$row["modOpmo"]."</td>";
					}
					else{
						echo "<td>".$row["modGM"]."</td>";
						echo "<td>".$row["ownOwnGM"]."</td>";
						echo showModOpmo($row["modOpmo"]);
					}

				echo "</tr>";
			}
		?>
	</table>

	</br>
	</br>
	<a href="../resEval.php">Ressource Evaluation</a>
	</br>
	<a href="../../index.php">Home</a>	


</body>

</html>
					



		
