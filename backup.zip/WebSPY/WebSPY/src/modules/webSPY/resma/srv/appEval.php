<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
include '../../mdbConnect.php';

$sql = "SELECT p.name, p.pid, a.appOpmo, a.testResult FROM plamaDB.appEvaluation a INNER JOIN orgDB.partitions p ON (p.id = a.partitions_id)";
$res = $conn->query($sql);
$rows = array();
while($r = mysqli_fetch_assoc($res)) {
	$rows[] = $r;
}
$json=json_encode($rows);

print $json;

?>