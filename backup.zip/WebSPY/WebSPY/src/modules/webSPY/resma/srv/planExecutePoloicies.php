<?php
include '../../mdbConnect.php';
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
$sql = "SELECT l.execTime, p.id, p.name, l.params FROM plamaDB.reconfigPolicies p INNER JOIN plamaDB.policyLog l ON p.id = l.reconfigPolicies_id ORDER BY l.execTime ASC";
$result = $conn->query($sql);	
class policies {
	public $datet = "";
	public $execTimeStr = "";
	public $id = "";
	public $name = "";
	public $params = "";
}
$e = new policies();
$res =array();
$json_array =array();
$r = array();

if ($result->num_rows > 0) {
	while($row = $result->fetch_assoc()) {
		if(empty($t0)){
			$t0 = $row["execTime"];			
			}		
		$execTime = $row["execTime"];	
		$execTimeStr = date("H:i:s", $execTime);
		$dt = round($execTime - $t0, 3);	
		
		/*$e->name = $row["name"];
		$e->datet  = $dt;
		$e->execTimeStr = $execTimeStr;
		$e->id= $row["id"];
		$e->params= $row["params"];
		 * echo "<tr><td>".$dt."</td><td>".$execTimeStr."</td>";
		echo "<td><a href=\"showPolicy.php?pid=".$row["id"]."\">".$row["id"]."</a></td>";
		echo "<td>".$row["name"]."</td><td>".$row["params"]."</td></tr>"; */
		
		$res ['name'] = $row["name"];
		$res ['delta'] = $dt;
		$res ['execTimeStr'] = $execTimeStr;
		$res ['id'] = $row["id"];
		$res ['params'] = $row["params"];
		$json_array = json_encode($res);
		//print $json_array;
		$j= json_decode($json_array, True);
		foreach ($j as $data){
			if ($data){
				array_push($r,$j);
			}	
				
		}
		
	} 
	
	
}
$array = array_values( array_unique( $r, SORT_REGULAR ) );
$x =json_encode($array);
print $x;

?>		