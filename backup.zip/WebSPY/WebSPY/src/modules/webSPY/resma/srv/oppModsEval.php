<?php
include '../../mdbConnect.php';

$sql = "SELECT m.type FROM orgDB.module m INNER JOIN plamaDB.ownOwnEval e ON (m.id = e.module_id)";
$result = $conn->query($sql);

if($result->num_rows == 1){
	$row = $result->fetch_assoc();
	if($row["type"] === "CPM") {
		$sql = "SELECT o.name, o.id, po.oppOwnGM, op.ownOppGM, xo.xmodOpmo, xo.xmodOpmoStep, xo.xmodTestResult FROM orgDB.module o INNER JOIN plamaDB.oppOwnGM po ON (o.id = po.module_id_opp) INNER JOIN plamaDB.ownOppGM op ON (o.id = op.module_id_opp) INNER JOIN plamaDB.xmodOpmo xo ON (o.id = xo.module_id_opp) ORDER BY o.name ASC";
		$result = $conn->query($sql);		
	}
	else {
		$sql = "SELECT o.name, o.id, po.oppOwnGM, op.ownOppGM FROM orgDB.module o INNER JOIN plamaDB.oppOwnGM po ON (o.id = po.module_id_opp) INNER JOIN plamaDB.ownOppGM op ON (o.id = op.module_id_opp) ORDER BY o.name ASC";
		$result = $conn->query($sql);		
	}
}

$rows = array();
while($r = mysqli_fetch_assoc($result)) {
	$rows[] = $r;
}
$json=json_encode($rows);

print $json;

?>