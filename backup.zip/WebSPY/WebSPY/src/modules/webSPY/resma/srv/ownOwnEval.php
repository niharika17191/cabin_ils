<?php
//include for connection to database
include '../../mdbConnect.php';
//query information
$sql = "SELECT m.id, m.name, o.modGM, o.ownOwnGM, o.modOpmo, o.modOpmoStep, o.bitResult FROM plamaDB.ownOwnEval o INNER JOIN orgDB.module m ON (m.id = o.module_id)";
$res = $conn->query($sql);
$rows = array();
while($r = mysqli_fetch_assoc($res)) {
	$rows[] = $r;
}
//Create json output
$json=json_encode($rows);

print $json;
?>