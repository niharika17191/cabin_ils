<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
include '../../mdbConnect.php';

$sql = "SELECT servSysOpmo, servSysOpmoStep, coordSysOpmo, coordSysOpmoStep, sysTest1Result, sysTest2Result FROM plamaDB.sysEval";
$res = $conn->query($sql);
$rows = array();
while($r = mysqli_fetch_assoc($res)) {
	$rows[] = $r;
}
$json=json_encode($rows);

print $json;

?>