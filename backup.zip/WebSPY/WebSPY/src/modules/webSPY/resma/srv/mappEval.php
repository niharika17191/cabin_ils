<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
include '../../mdbConnect.php';

$rows = array();

$sql = "SELECT o.name, o.id FROM orgDB.module o INNER JOIN plamaDB.ownOwnEval p ON (p.module_id = o.id)";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
	$row = $result->fetch_assoc();
	$modName = $row["name"];
	$modId = $row["id"];
}
else {
	die();
}

$sql = "SELECT p.mappGM, p.qos, p.ms, m.name FROM plamaDB.mappEval p INNER JOIN orgDB.module m ON (m.id = p.module_id_host) WHERE p.module_id_host = '".$modId."'";
$result = $conn->query($sql);
if($result->num_rows > 0) {
	$row = $result->fetch_assoc();
	$row["role"] = "own";
	$rows[] = $row;	
}
$sql = "SELECT p.mappGM, p.qos, p.ms, m.name FROM plamaDB.mappEval p INNER JOIN orgDB.module m ON (m.id = p.module_id_host) WHERE p.module_id_host != '".$modId."' ORDER BY m.name ASC";
$result = $conn->query($sql);
if($result->num_rows > 0) {
	while($row = $result->fetch_assoc()) {		
		$row["role"] = "opp";
		$rows[] = $row;	
	}		
}

$json=json_encode($rows);

print $json;


?>