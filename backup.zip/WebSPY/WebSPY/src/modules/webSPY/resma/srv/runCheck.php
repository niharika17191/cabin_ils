<?php
	
	$plamaPid = shell_exec("ps -C PLAMA -o pid=");
	//$plamaPid = 1;
	if(empty($plamaPid)) {
		$data->pid =  0;
		$data->plamaRun = false;
		}
	else{
		$data->pid =  $plamaPid;
		$data->plamaRun = true;
	}
	$json=json_encode($data);
	
	print $json;
?>