<!DOCTYPE html>

<?php
	$policyId = $_GET["pid"];	
	
	//1.) Connect to module DB
	$servername = "localhost";
	$username = "root";
	$password = "jagen";
	// Create connection
	$conn = new mysqli($servername, $username, $password);
	// Check connection
	if ($conn->connect_error) {
   	die("Connection failed: " . $conn->connect_error);
		}
	$sql = "SELECT p.id, p.priority, p.name, p.description FROM plamaDB.reconfigPolicies p WHERE id = '".$policyId."'";
	$result = $conn->query($sql);
	if ($result->num_rows > 0) {
   	$row = $result->fetch_assoc();
	}
	$conn->close();
?>

<html>

<head>
<title>Show reconfig policy</title>
</head>


<body>
<h2>Reconfiguration policy properties</h2>

<?php
	echo "<b>Id: </b>".$row["id"]."<br/>";
	echo "<b>Name: </b>".$row["name"]."<br/>";
	echo "<b>Priority: </b>".$row["priority"]."<br/>";
	echo "<b>Description: </b>".$row["description"]."<br/>";
?>


<br />
<a href="resPlan.php">Back</a>
</body>
</html>