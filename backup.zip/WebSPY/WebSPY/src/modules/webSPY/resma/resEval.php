<!DOCTYPE html>

<?php
include 'resMaFunctions.php';

$pagenameShort = "ResEval";
$pagenameLong = "Ressource Evaluation";
include 'runCheck.php';
include '../mdbConnect.php';
include '../modStateCheck.php';
?>

<html>
<head>
<meta http-equiv="refresh" content="2" >
<style>
table, th, td {
	border: 1px solid black;
}
</style>
<title>
<?php echo gethostname() . " - " . $pagenameShort; ?>
</title>
</head>

<body>
<h2>Ressource Evaluation</h2>
<?php include '../ownModInfo.php'; ?>


<h3><a href="history/ownModule.php">Own Module</a></h3>
<table>
	<tr>
	<th>Type</th> <th>GM</th> <th>Opmo</th>
	</tr>
	
<?php
$sql = "SELECT modGM, ownOwnGM, modOpmo, modOpmoStep FROM plamaDB.ownOwnEval";
$result = $conn->query($sql);
if($result->num_rows > 0) {
	$row = $result->fetch_assoc();
	echo "<tr><td>Module</td>". showGMCell($row["modGM"]) .  "<td>-</td></tr>";
	echo "<tr><td>Own -> Own</td>".showGMCell($row["ownOwnGM"]) . showModOpmo($row["modOpmo"], $row["modOpmoStep"]) . "</tr>";	
	}
?>
</table>

<h3><a href="history/oppModules.php?oppMod=All&PoV=Both">Opp Modules</a></h3>

<table>
	<tr>
		<th rowspan="2">Name</th> <th rowspan="2">ID</th> <th colspan="2">GM</th>	<th rowspan="2">Opmo</th>
	</tr>
	<tr>		
		<th>opp -> own</th> <th>own -> opp</th>	
	</tr>

<?php
$sql = "SELECT m.type FROM orgDB.module m INNER JOIN plamaDB.ownOwnEval e ON (m.id = e.module_id)";
$result = $conn->query($sql);

if($result->num_rows == 1){
	$row = $result->fetch_assoc();
	if($row["type"] === "CPM") {		
		$sql = "SELECT o.name, o.id, po.oppOwnGM, op.ownOppGM, xo.xmodOpmo FROM orgDB.module o INNER JOIN plamaDB.oppOwnGM po ON (o.id = po.module_id_opp) INNER JOIN plamaDB.ownOppGM op ON (o.id = op.module_id_opp) INNER JOIN plamaDB.xmodOpmo xo ON (o.id = xo.module_id_opp) ORDER BY o.name ASC";
		$result = $conn->query($sql);

		if ($result->num_rows > 0) {
			while($row = $result->fetch_assoc()) {
				echo "<tr><td><b>".$row["name"]."</b></td><td><a href='history/oppModules.php?oppMod=".$row["name"]."&PoV=Both'>".$row["id"]."</a></td>".showGMCell($row["oppOwnGM"]).showGMCell($row["ownOppGM"]).showModOpmo($row["xmodOpmo"])."</tr>"; 
			} 
		}
	}
	else {
		$sql = "SELECT o.name, o.id, po.oppOwnGM, op.ownOppGM FROM orgDB.module o INNER JOIN plamaDB.oppOwnGM po ON (o.id = po.module_id_opp) INNER JOIN plamaDB.ownOppGM op ON (o.id = op.module_id_opp) ORDER BY o.name ASC";
		$result = $conn->query($sql);

		if ($result->num_rows > 0) {
			while($row = $result->fetch_assoc()) {
				echo "<tr><td><b>".$row["name"]."</b></td><td><a href='history/oppModules.php?oppMod=".$row["name"]."&PoV=Both'>".$row["id"]."</a></td>".showGMCell($row["oppOwnGM"]).showGMCell($row["ownOppGM"])."<td>-</td></tr>"; 
			} 
		}
	}
}
?>
	
</table>


<h3><a href="history/mapps.php">Mapps</a></h3>

<table>
	<tr>
		<th>Role</th><th>Host</th><th>GM</th><th>QoS</th><th>M/S</th>
	</tr>
	
<?php
$sql = "SELECT p.mappGM, p.qos, p.ms, m.name FROM plamaDB.mappEval p INNER JOIN orgDB.module m ON (m.id = p.module_id_host) WHERE p.module_id_host = '".$modId."'";
$result = $conn->query($sql);
if($result->num_rows > 0) {
	$row = $result->fetch_assoc();
	echo "<tr><td>own</td><td>".$row["name"]."</td>";
	echo showGMCell($row["mappGM"]);
	echo showQoSCell($row["qos"]);
	echo showMSCell($row["ms"]);
	echo "</tr>";		
}
$sql = "SELECT p.mappGM, p.qos, p.ms, m.name FROM plamaDB.mappEval p INNER JOIN orgDB.module m ON (m.id = p.module_id_host) WHERE p.module_id_host != '".$modId."' ORDER BY m.name ASC";
$result = $conn->query($sql);
if($result->num_rows > 0) {
	while($row = $result->fetch_assoc()) {
		echo "<tr><td>opp</td><td>".$row["name"]."</td>";
		echo showGMCell($row["mappGM"]);
		echo showQoSCell($row["qos"]);
		echo showMSCell($row["ms"]);
		echo "</tr>";
	}		
}


?>		

</table>

</br>
</br>
<a href="history/truncate.php"><button>Delete history</button></a>


</br>
</br>
<a href="../index.php">Home</a>
</body>
</html>

<?php
$conn->close();
?>
