<!DOCTYPE html>
<?php
include '../mdbConnect.php';
?>

<html>
<head>
<meta http-equiv="refresh" content="2" >
<style>
table, th, td {
	border: 1px solid black;
}
</style>
<title>
<?php echo gethostname() . " - LORG-Log"; ?>
</title>
</head>
<body>
<h2>LORG Log File</h2>

<a href="lorgStatus.php">Back</a>

<?php include '../ownModInfo.php'; ?>

<h3>File Content</h3> 

<?php

$lorgfile = file("/home/diana/AAA/log/lorg.log");
foreach($lorgfile as $i => $line){
	echo $line."<br>";	
	}
?>


</body>
</html>
