<?php
include "moduleStateDB.php";

$modState = getStateRaw($conn, "state");
if($modState === "MST_COR_NOT_POWERED"){
		echo "<html><head><meta http-equiv=\"refresh\" content=\"2\" >";
		echo "<title>". gethostname() . " - " . $pagenameShort . "</title>";
		echo "</head><body>";		
		echo "Module is not powered<br/>";
		echo "<a href=\"../index.php\">Home</a>";
		echo "</body></html>";
		die();	
	}
?>