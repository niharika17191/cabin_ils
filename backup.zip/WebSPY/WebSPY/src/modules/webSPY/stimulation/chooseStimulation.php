<!DOCTYPE html>

<?php
$pagenameShort = "Stimulation";
$pagenameLong = "Failure Stimulation";
include '../mdbConnect.php';
include '../moduleStateDB.php';


if($_POST["event"] != "") {
	//form chooseStimulation
	echo "<h3>Result</h3>";
	$event =	$_POST["event"];
	$opp = $_POST["oppid"];
	$cmdPath = "/home/diana/test/";
	shell_exec("cd /home/diana/test");
	if	($event == "restart"){
		$cmd = $cmdPath . "simulateModuleRestart.sh";
		}
	else if($event == "pwrIr") {
		$cmd = $cmdPath . "simulateModulePassive.sh";
		}
	else if($event == "startup") {		
		$cmd = $cmdPath . "simulateModuleStartup.sh";
		}
	else if($event == "internalFail") {
		$cmd = $cmdPath . "simulateModuleInternalFail.sh";		
		}
	else if($event == "corrCC") {
		$cmd = $cmdPath . "simulateCorruptMessageCPM_CPM.sh";		
		}
	else if($event == "corrCI") {
		$cmd = $cmdPath . "simulateCorruptMessageCPM_IOM.sh";		
		}
	else if($event == "corrIC") {
		$cmd = $cmdPath . "simulateCorruptMessageIOM_CPM.sh";		
		}
	else if($event == "oppFI") {
		$cmd = $cmdPath . "simulateOppModuleFail.sh" . " " . $opp;		
		}	
	echo "Command: " . $cmd . "<br/>";
	$ret = shell_exec($cmd);
	echo $ret;
}
elseif($_POST["state"] != "") {
	//form moduleStateEvents
	$state = $_POST["state"];
	$sock = socket_create(AF_INET, SOCK_DGRAM, SOL_UDP);
	$len = strlen($state);
	socket_sendto($sock, $state, $len, 0, '127.0.0.1', 60001);
	socket_close($sock);
	echo "Sent external event " . $state . "<br/>";
}
elseif($_POST["tinit"] != "") {
	// form moduleParams
	$t_init = $_POST["tinit"];
	$t_bit = $_POST["tbit"];
	$bitRes = $_POST["bitres"];
	
	$sql = "UPDATE moduleStateSimulation.moduleParams p SET `t_init_ms` = '".$t_init."', `t_bit_ms` = '".$t_bit."', `bitResult` = '".$bitRes."' WHERE `id` = 1 ";
	$conn->query($sql);
	}
?>


<html>
<head>
<meta http-equiv="refresh" content="2" >
<style>
table, th, td {
	border: 1px solid black;
}
</style>
<title>
<?php echo gethostname() . " - " . $pagenameShort; ?>
</title>
</head>

<body>
<h2>Module Simulation</h2>

<?php include '../ownModInfo.php'?> 


<h3>Module State Simulation</h3>

<?php
	$pid = shell_exec("ps -C ModCom -o pid=");	
	if(empty($pid)) {
		echo "<font color=\"red\">Warning: ModCom Daemon is NOT running! Restart with 'sudo service modcom start'.</font> <br/>";
		}
?>


<h4>Attributes</h4>


<table>
<tr>
<th>Attr.</th><th>Value</th>
</tr>
<tr><td>State</td>

<?php
	$val = getFormatedState($conn);
	echo $val;
 ?>
 
</tr>
<tr><td>T_init [ms]</td>

<?php
	$val = getParam($conn, "t_init_ms");
	echo "<td>".$val."</td>";
?>

</tr>
<tr><td>T_bit [ms]</td>

<?php
	$val = getParam($conn, "t_bit_ms");
	echo "<td>".$val."</td>";
?>

</tr>
<tr><td>Bit Result</td>

<?php
	$val = getParam($conn, "bitResult");
	if($val === "1") {
		echo "<td>PASS</td>";		
		}
	else {
		echo "<td>FAIL</td>";		
		}
?>

</tr>
</table>

<br/>
<a href="modifyModuleParams.php">Modify Attributes</a>

<h4>External Events</h4>
<form name="moduleStateEvents" action="chooseStimulation.php" method="POST">
<input type="radio" name="state" value="PwrOn">Power on</input><br/>
<input type="radio" name="state" value="PwrOff">Power off</input><br/>
<input type="radio" name="state" value="AllIfUp">All Interfaces up</input><br/>
<input type="radio" name="state" value="FailDect">Detectable Failure</input><br/>
<input type="radio" name="state" value="FailNDect">Undetectable Failure</input><br/>
<input type="radio" name="state" value="ResetState">Reset State</input><br/>
<br/>
<button id="sendStateEvent">Send Event</button>
</form>

<h3>Failure Simulation</h3>

<h4>Corrupt Message</h4>
<form name="chooseStimulation" action="chooseStimulation.php" method="POST">

<input type="radio" name="event" value="corrCC">Send corrupt CPM->CPM message</input><br/>
<input type="radio" name="event" value="corrCI">Send corrupt CPM->IOM message</input><br/>
<input type="radio" name="event" value="corrIC">Send corrupt IOM->CPM message</input><br/>

<h4>Opp Failure</h4>
<input type="radio" name="event" value="oppFI">Receive corrupt message, opp-id = </input><input type="text" width="20" name="oppid" /><br/>
<br/>
<button id="exec">Execute Stimulation</button>

</form>





<br/>
<a href="../index.php">Home</a>
</body>
</html>

<?php
$conn->close();
?>