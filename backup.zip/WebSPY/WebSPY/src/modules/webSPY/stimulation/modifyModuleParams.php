<!DOCTYPE html>

<?php
	include '../mdbConnect.php';
	include '../moduleStateDB.php';
?>

<html>
<head>
<style>
table, th, td {
	border: 1px solid black;
}
</style>
<title>
Modify Module Attr
</title>
</head>

<body>
<h1>Modify Module Attributes</h1>

<form name="moduleParams" action="chooseStimulation.php" method="POST">
<table>
<tr>
<th>Attr.</th><th>Value</th>
</tr>
<tr><td>T_init [ms]</td><td>
<input type="text" name="tinit" value=

<?php
	$val = getParam($conn, "t_init_ms");
	echo "\"".$val."\"";
?>

></input>
</td></td></tr>
<tr><td>T_bit [ms]</td><td>
<input type="text" name="tbit" value=

<?php
	$val = getParam($conn, "t_bit_ms");
	echo "\"".$val."\"";
?>

></input>
</td></tr>
<tr><td>Bit Result</td><td>

<?php
	$val = getParam($conn, "bitResult");
	if($val === "1") {
		echo "<input type=\"radio\" name=\"bitres\" value=\"1\" checked>pass</input>";
		echo "<input type=\"radio\" name=\"bitres\" value=\"0\">fail</input>";
		}
	else {
		echo "<input type=\"radio\" name=\"bitres\" value=\"1\">pass</input>";
		echo "<input type=\"radio\" name=\"bitres\" value=\"0\" checked>fail</input>";
		}
?>

</td></tr>
</table>
<br/>
<button id="changeAttrs">Submit</button>
</form>

</body>