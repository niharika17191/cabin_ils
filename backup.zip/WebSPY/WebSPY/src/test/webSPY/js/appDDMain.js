/**
 * 
 */

var app = angular.module('appDDMain', []);

app.controller('updateNodeList', function($scope, $interval, $http, $timeout){

	
	$scope.loadList = function(){
		$http.get("srv/demoNodeList.php").then(function(response){
			$scope.nodes = response.data;		
		});
	}
	
	
	//Add svg
	$scope.loadTopo = function(){
		var parElem = document.getElementById("topoImg");
		var topoImg = new XMLHttpRequest();
		topoImg.open("GET", "http://192.168.1.150/webSPY/srv/getSystemTopology.php", true);		
		topoImg.timeout = 1000;
		topoImg.send();
		topoImg.onload = function(e){
			parElem.innerHTML = topoImg.responseText;
			var svg = parElem.children[0]; 
			//adjust width to panel
			svg.setAttribute("width", "100%");
			svg.setAttribute("height", "");
			//add click listeners
			nodes = document.getElementsByClassName("node");
			for(var i = 0; i < nodes.length; i++){
				nodes[i].onclick = function () {
					 var id = this.getAttribute("id");
					 for(var j = 0; j < $scope.nodes.length; j++){
						 if($scope.nodes[j].topoId == id){
							 $scope.selectNode($scope.nodes[j]);
							 break;
						 }
					 }
				}
				nodes[i].ondblclick = function(){
					var id = this.getAttribute("id");
					 for(var j = 0; j < $scope.nodes.length; j++){
						 if($scope.nodes[j].topoId == id){
							 $scope.gotoModuleWebspy($scope.nodes[j]);
							 break;
						 }
					 }
				}
			}
			if($scope.selNode){
				$scope.selectNode($scope.selNode);
			}			
			$scope.showTopo = true;
		}	
		topoImg.ontimeout = function(e){
			parElem.innerHTML = "";
			$scope.showTopo = false;
		}
	}
	
	
		
	
$scope.selectNode = function(selection){
	$scope.selNode = selection;
	if(selection.topoId){
		var parent = document.getElementById("topoImg");
		if(parent.children.length > 0){
			
			//reset prev Selection
			if($scope.oldId){
				var oldNode = document.getElementById($scope.oldId);
				oldNode.children[1].setAttribute("fill", $scope.oldColor);
			}
			
			//set selected node			
			var node = document.getElementById(selection.topoId);			
			$scope.oldColor = node.children[1].getAttribute("fill");
			$scope.oldId = selection.topoId;			
			node.children[1].setAttribute("fill", "orange");
			
			
		}
	}
	
	
	
	
}
	
$scope.gotoModuleWebspy = function(selection){
	var url = "";
	url = "http://" + selection.IP + "/webSPY";
	window.location.href = url;
}
	
$scope.startDemo = function(){
	$scope.demoStatus = "starting..";
	$scope.demoStartBtnState = "disabled";
	$http.get("srv/startDemo.php").then(function(response){
		$scope.demoStatus = "";
		$scope.demoStatusAlert = "Startup script completed.";
		$scope.demoStartBtnState = "active";
		$timeout(function(){				
			$scope.demoStatusAlert = "";
		}, 2000);
	});
}
	
$scope.stopDemo = function(){
	$scope.demoStatus = "shutdown..";
	$scope.demoStopBtnState = "disabled";
	$http.get("srv/stopDemo.php").then(function(response){
		$scope.demoStatus = "";
		$scope.demoStatusAlert = "Shutdown script completed.";
		$scope.demoStopBtnState = "active";
		$timeout(function(){
			$scope.demoStatusAlert = null;				
		}, 6000);
	});
}

$scope.startModule = function(node){
	var url = "";
	
	url = "srv/startModule.php?mac=" + node.MAC;
	$http.get(url).then(function(response){			
	});
}

$scope.shutdownModule = function(node){
	var url = "";
	
	url = "srv/shutdownModule.php?host=" + node.Hostname;
	$http.get(url).then(function(response){			
	});
}

$scope.restartModule = function(node){
	var url = "";
	
	url = "srv/restartModule.php?host=" + node.Hostname;
	$http.get(url).then(function(response){			
	});
}

$scope.simEvent = function(node, ev){
	var url = "";
	
	url = "http://" + node.IP + "/webSPY/stimulation/srv/simulateEvent.php?state=" + ev;
	$http.get(url).then(function(response){		
	});
}


//Init vars
$scope.selName="";
$scope.demoStatus = "";
$scope.demoStatusAlert = null;
$scope.showTopo = false;
//Set cyclic updates
$interval($scope.loadList, 2000);
$interval($scope.loadTopo, 10000);
//Initial updates
$scope.loadList();
$scope.loadTopo();


});


app.filter('removePrefix', function() {
    return function(x) {
        var txt = "";
        var i;
        
        i = x.indexOf("_");
        txt = x.slice(i+1, x.length);
        
        return txt;
    };
});


app.filter('nodeTableWidth', function(){
	return function(x){
		if(x){
			return "col-md-8";
		}
		else{
			return "col-md-12";
		}
	}
});