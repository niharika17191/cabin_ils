<?php
$ModuleMAC = $_GET["mac"];
$cmd = 'wakeonlan '.$ModuleMAC;
$out = shell_exec($cmd);
print 'Done, cmd='.$cmd;
?>