<?php
   $out = shell_exec('/home/pi/scripts/stopDD.sh');
   sleep(2);
   print "Done";
?>