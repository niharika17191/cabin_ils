<?php
include 'testDBConnect.php';


$sql = "SELECT m.ModuleID, m.IP FROM Demonstrator_DB.Module_DB m INNER JOIN Demonstrator_DB.TopoInfo t ON (t.Module_DB_ModuleID = m.ModuleID) WHERE m.status='On'";
$result = $conn->query ( $sql );

$ctx = stream_context_create(array(	'http' => array('timeout' => 1)	));
while ( $row = $result->fetch_assoc () ) {
	$url = "http://" . $row ["IP"] . "/webSPY/srv/moduleInfo.php";	
	$json = file_get_contents ( $url, 0, $ctx );
	if (! ($json === false)) {
		$modInfo = json_decode ( $json, true );		
		if (!empty ( $modInfo )) {			
			$sql = "UPDATE Demonstrator_DB.TopoInfo SET `topoName` = '".$modInfo["modName"]."', `topoId`='".$modInfo["modId"]."', `simState` = '".$modInfo["state"]."', `type` = '".$modInfo["type"]."' WHERE Module_DB_ModuleId = '".$row["ModuleID"]."'";
			$conn->query ( $sql );
		}
	}
}

$sql = "SELECT m.ModuleID FROM Demonstrator_DB.Module_DB m INNER JOIN Demonstrator_DB.TopoInfo t ON (t.Module_DB_ModuleID = m.ModuleID) WHERE m.status='Off'";
$result = $conn->query ( $sql );

while ( $row = $result->fetch_assoc () ) {
	$sql = "UPDATE Demonstrator_DB.TopoInfo SET `topoName` = '', `topoId`='', `simState` = '' WHERE Module_DB_ModuleId = '".$row["ModuleID"]."'";
	$conn->query ( $sql );
}


$conn->close();
?>