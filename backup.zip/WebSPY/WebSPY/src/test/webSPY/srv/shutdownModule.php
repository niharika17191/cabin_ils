<?php
$hostName = $_GET["host"];
$cmd = 'ssh '.$hostName.' \'sudo  poweroff\'';
$out1 = shell_exec($cmd);
print 'Done, cmd='.$cmd;
?>