<?php
	$out = shell_exec('/home/pi/scripts/startDD.sh');
	sleep(2);
	echo "<pre>$out</pre>";
?>