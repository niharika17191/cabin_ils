<?php
include 'testDBConnect.php';

//get ips
$sql = "SELECT IP FROM Demonstrator_DB.Module_DB";
$result = $conn->query($sql);
$ipText = "";
$i = 0;
while($row = $result->fetch_assoc()) {
	$status[$row["IP"]] = "Off";
	$ipText = $ipText . $row["IP"] . " ";
	$ips[$i] = $row["IP"];
	$i = $i + 1;
}
//ping modules
$cmd = "sudo fping -a -q -r0 ".$ipText;
$res = exec($cmd, $onIps);

foreach($onIps as $ip){
	$status[$ip] = "On";
}

//update state in db
foreach($ips as $ip){
	$sql = "UPDATE `Demonstrator_DB`.`Module_DB` SET `status`='".$status[$ip]."' WHERE `IP`='".$ip."'";
	$conn->query($sql);
}

$conn->close();
?>