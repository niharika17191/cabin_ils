<?php
$hostname = gethostname();
?>


<html>

<head>
<title>
<?php echo $hostname . " - webSPY";  ?>
</title>
</head>


<body>
<h2>WebSPY</h2>
<?php echo "Hostname: " . $hostname . "<br/>";?>
<h3>Pages</h3>
<a href="switchState.php" >Switch State</a><br />
<a href="moduleConfig.xml">Module Config</a><br />
<a href="switches/restore.xml">Restore File</a><br />
<a href="switches/routingTableDB.xml">RoutingTable-DB</a><br />


<br><br>
<a href="http://192.168.1.180/webSPY" >Main</a>

</body>
</html>