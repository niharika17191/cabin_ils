<?php
function str_rev_ip($str)
{
	$ar=explode(".",$str);
	return "$ar[3].$ar[2].$ar[1].$ar[0]";
}


$xmlStr = file_get_contents("../switches/state.xml");
$xml = new SimpleXMLElement($xmlStr);

$data->state = $xml->state->__toString();
$data->modName = "";
$data->modId = "";
$data->type = "";


if (!($data->state == "DYNAMIC ROUTING")) {	
	$xmlStr = file_get_contents("../switches/restore.xml");
	$xml = new SimpleXMLElement($xmlStr);
	$addr = $xml->interfaceAddresses->interfaceConfig[0]["addr"];
	if(!empty($addr)){
		$addrNum = ip2long(str_rev_ip($addr));
		// Connect to org DB
		$servername = "192.168.1.150";
		$username = "root";
		$password = "jagen";
		// Create connection
		$conn = new mysqli ( $servername, $username, $password );
		// Check connection
		if (!($conn->connect_error)) {
			$sql = "SELECT m.id, m.name FROM orgDB.module m INNER JOIN orgDB.interfaceAddr i ON (i.module_id = m.id) WHERE i.ipAddr = '".$addrNum."'";
			$res = $conn->query($sql);
			if($res->num_rows == 1){
				$row = $res->fetch_assoc();
				$data->modName = $row["name"];
				$data->modId = $row["id"];
			}						
			$conn->close();
		}		
	}
}

$xmlStr = file_get_contents("/home/diana/moduleConfig.xml");
$xml = new SimpleXMLElement($xmlStr);

$data->type = $xml->type->__toString();

$json = json_encode ( $data );
print $json;
?>