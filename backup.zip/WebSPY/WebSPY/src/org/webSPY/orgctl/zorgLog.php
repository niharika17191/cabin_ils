<!DOCTYPE html>

<html>
<head>
<meta http-equiv="refresh" content="2" >
<style>
table, th, td {
	border: 1px solid black;
}
</style>
<title>
<?php echo gethostname() . " - ZORG-Log"; ?>
</title>
</head>
<body>
<h2>ZORG Log File</h2>

<a href="zorgControl.php">Back</a>


<h3>File Content</h3> 

<?php

$zorgfile = file("/home/diana/ORG/log/zorg.log");
foreach($zorgfile as $i => $line){
	echo $line."<br>";	
	}
?>


</body>
</html>
