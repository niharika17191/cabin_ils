<html>
<head>
<title>Mod To ORG</title>
</head>

<body>


<?php
	$cmd = "sudo su - diana -c \"ssh diana@192.168.1.100 '/home/diana/scripts/modulesToORG.sh'\"";
	$res = shell_exec($cmd);
	echo "All Modules are now in ORG-Mode<br>";	
?>

<br><a href="zorgControl.php" >Back</a>

</body>

</html>