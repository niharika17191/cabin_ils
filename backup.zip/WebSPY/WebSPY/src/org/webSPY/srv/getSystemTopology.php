<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: image/svg+xml; charset=UTF-8");
echo file_get_contents("../img/SystemTopology.svg");
?>