<!DOCTYPE html>

<?php

$pagenameShort = "SysLay";
$pagenameLong = "System Layout";
include '../odbConnect.php';
?>

<html>
<head>
<style>
table, th, td {
	border: 1px solid black;
}
</style>
<title>
<?php echo gethostname() . " - " . $pagenameShort; ?>
</title>
</head>


<body>
<h2>System Layout</h2>

<?php
//update sysfu allocation
if(!empty($_POST["update"])) {
	$sql = "SELECT s.id  FROM orgDB.systemFunction s";
	$result = $conn->query($sql);	
	while($row = $result->fetch_assoc()) {
		$sysfu = "sysfu".$row["id"];
		if(!empty($_POST[$sysfu])) {
				$alloc = "1";
			}	
			else {
				$alloc = "0";
				}
			$sql2 = "UPDATE `orgDB`.`systemFunction` SET `isAllocated`=".$alloc." WHERE `id`='".$row["id"]."'";		
			$conn->query($sql2);
		}	
	}
//delete aggregat type
else if(!empty($_POST["delAgg"])) {	
	$sql = "DELETE FROM orgDB.aggregatType WHERE id = '".$_POST["delAgg"]."'";
	$conn->query($sql);
	}
//add aggregat type
else if(!empty($_POST["addAggName"])) {
	$sql = "INSERT INTO `orgDB`.`aggregatType` (`name`) VALUES ('".$_POST["addAggName"]."');";
	$conn->query($sql);
	}
//add sysfu 
else if(!empty($_POST["addSysfu"])) {
	$sql = "INSERT INTO orgDB.systemFunction (`name`, `isAllocated`) VALUES ('".$_POST["addSysfuName"]."', '0')";
	$conn->query($sql);
	$sql = "SELECT s.id FROM orgDB.systemFunction s WHERE s.name ='".$_POST["addSysfuName"]."'";
	$conn->query($sql);	
	$result = $conn->query($sql);
	if($result->num_rows > 0) {
		$row = $result->fetch_assoc();
		$id = $row["id"];
		if(!empty($_POST["addAppName1"])) {
			$sql = "INSERT INTO orgDB.application (`systemFunction_id`, `name`, `execName`) VALUES ('".$id."', '".$_POST["addAppName1"]."', '".$_POST["addAppName1"]."')";
			$conn->query($sql);			
			}
		if(!empty($_POST["addAppName2"])) {
			$sql = "INSERT INTO orgDB.application (`systemFunction_id`, `name`, `execName`) VALUES ('".$id."', '".$_POST["addAppName2"]."', '".$_POST["addAppName2"]."')";
			$conn->query($sql);			
			}
		if(!empty($_POST["addAppName3"])) {
			$sql = "INSERT INTO orgDB.application (`systemFunction_id`, `name`, `execName`) VALUES ('".$id."', '".$_POST["addAppName3"]."', '".$_POST["addAppName3"]."')";
			$conn->query($sql);			
			}	
		}		
	}
//delete sysfu
else if(!empty($_POST["delSysfu"])){
	$sql = "DELETE FROM orgDB.systemFunction WHERE id='".$_POST["delSysfu"]."'";
	$conn->query($sql);
	echo $sql;
	}
//delete all layout information
else if(!empty($_POST["delSysLayout"])){
	$sql = "DELETE FROM orgDB.systemFunction";
	$conn->query($sql);
	$sql = "DELETE FROM orgDB.aggregatType";
	$conn->query($sql);
	}
?>

<form action="systemLayout.php" method="POST">

<button id="delSysLayout" name="delSysLayout" value="delSysLayout">Delete System Layout</button>


<h3>System Functions</h3>



<table>
<tr><th>Id</th><th>Name</th><th>Applications</th><th>Allocated</th><th>Operation</th></tr>

<?php
$sql = "SELECT s.id, s.name, s.isAllocated FROM orgDB.systemFunction s ORDER BY s.id ASC";
$result = $conn->query($sql);
if($result->num_rows > 0) {
	while($row = $result->fetch_assoc()) {
		$sql2 = "SELECT a.execName FROM orgDB.application a WHERE a.systemFunction_id = '" . $row["id"] . "'";
		$result2 = $conn->query($sql2);
		
		echo "<tr>";
		echo "<td>" . $row["id"] . "</td>";
		echo "<td>" . $row["name"] . "</td>";		
		echo "<td>";
		if($result2->num_rows > 0) {
			while($row2 = $result2->fetch_assoc()) {
				echo $row2["execName"] . ", ";		
				}
			}
		else {
			echo "-";
			}		
		echo "</td>";		 
		echo "<td><input type = \"checkbox\" name = \"sysfu".$row["id"]."\" value = \"".$row["id"]."\"";
		if($row["isAllocated"] == "1") {
			echo " checked />";
			}
		else {
			echo " />";
			}
		echo "</td>";
		echo "<td><button id=\"delSysfu\" name=\"delSysfu\" value=\"".$row["id"]."\">Delete</button></td>";
		echo "</tr>";
	}		
}
?>
<tr>
<td></td>
<td valign="top"><input type= "text" name="addSysfuName" size="15" /></td>
<td><input type= "text" name="addAppName1" size="10" /><br><input type= "text" name="addAppName2" size="10" /><br><input type= "text" name="addAppName3" size="10" /></td>
<td></td>
<td valign="top"><button id="addSysfu" name="addSysfu" value="addSysfu">Add</button></td>
</tr>

</table>
<br/>
<button id="apply" name="update" value="true">Update Allocation</button>

<h3>Aggregat Types</h3>

<table>
<tr><th>Id</th><th>Type</th><th>Operation</th></tr>
<?php
$sql = "SELECT a.id, a.name FROM orgDB.aggregatType a ORDER BY a.id ASC";
$result = $conn->query($sql);
if($result->num_rows > 0) {
	while($row = $result->fetch_assoc()) {
		echo "<tr><td>" . $row["id"] . "</td><td>" . $row["name"] . "</td>";
		echo "<td><button id=\"delete\" name=\"delAgg\" value=\"".$row["id"]."\">Delete</button> </td>";
		echo "</tr>"; 
	}		
}
?>
<tr><td></td><td><input type="text" name="addAggName" size="10" /></td><td><button id="addAgg" name="addAgg" value="addAgg">Add</button></td></tr>
</table>

<br/>

</form>

</br>
<a href="../index.php">Home</a>
</body>
</html>

<?php
$conn->close();
?>