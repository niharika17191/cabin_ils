CREATE TABLE plamaDB.mappEval_history LIKE plamaDB.mappEval;

ALTER TABLE plamaDB.mappEval_history MODIFY COLUMN module_id_host int(11) NOT NULL, 
   DROP PRIMARY KEY, ENGINE = MyISAM, ADD action VARCHAR(14) DEFAULT 'insert' FIRST, 
   ADD revision INT(6) NOT NULL AUTO_INCREMENT AFTER action,
   ADD dt_datetime timestamp DEFAULT CURRENT_TIMESTAMP NOT NULL AFTER revision,
   ADD PRIMARY KEY (module_id_host, revision);

   
CREATE TABLE plamaDB.oppMod_history LIKE plamaDB.oppOwnGM;

ALTER TABLE plamaDB.oppMod_history MODIFY COLUMN module_id_opp int(11) NOT NULL, 
   DROP PRIMARY KEY, ENGINE = MyISAM, ADD action VARCHAR(16) DEFAULT 'insert' FIRST, 
   ADD revision INT(6) NOT NULL AUTO_INCREMENT AFTER action,
   ADD dt_datetime timestamp DEFAULT CURRENT_TIMESTAMP NOT NULL AFTER revision,
   ADD ownOppGM ENUM('OFF.RST','OFF.ISO','ON','NA','NIL'),
   ADD PRIMARY KEY (module_id_opp, revision);
   

CREATE TABLE plamaDB.ownOwnEval_history LIKE plamaDB.ownOwnEval;

ALTER TABLE plamaDB.ownOwnEval_history MODIFY COLUMN module_id int(11) NOT NULL, 
   DROP PRIMARY KEY, ENGINE = MyISAM, ADD action VARCHAR(14) DEFAULT 'insert' FIRST, 
   ADD revision INT(6) NOT NULL AUTO_INCREMENT AFTER action,
   ADD dt_datetime timestamp DEFAULT CURRENT_TIMESTAMP NOT NULL AFTER revision,
   ADD PRIMARY KEY (module_id, revision);


CREATE TABLE plamaDB.switchConfig_history LIKE plamaDB.switchConfig;

ALTER TABLE plamaDB.switchConfig_history MODIFY COLUMN module_id int(11) NOT NULL, 
   DROP PRIMARY KEY, ENGINE = MyISAM, ADD action VARCHAR(8) DEFAULT 'insert' FIRST, 
   ADD revision INT(6) NOT NULL AUTO_INCREMENT AFTER action,
   ADD dt_datetime timestamp DEFAULT CURRENT_TIMESTAMP NOT NULL AFTER revision,
   ADD PRIMARY KEY (module_id, revision);


CREATE TABLE plamaDB.xModuleConfig_history LIKE plamaDB.xModuleConfig;

ALTER TABLE plamaDB.xModuleConfig_history MODIFY COLUMN module_id int(11) NOT NULL, 
   DROP PRIMARY KEY, ENGINE = MyISAM, ADD action VARCHAR(8) DEFAULT 'insert' FIRST, 
   ADD revision INT(6) NOT NULL AUTO_INCREMENT AFTER action,
   ADD dt_datetime timestamp DEFAULT CURRENT_TIMESTAMP NOT NULL AFTER revision,
   ADD PRIMARY KEY (module_id, revision);


CREATE TABLE plamaDB.partitionConfig_history LIKE plamaDB.partitionConfig;

ALTER TABLE plamaDB.partitionConfig_history MODIFY COLUMN pid int(11) NOT NULL, 
   DROP PRIMARY KEY, ENGINE = MyISAM, ADD action VARCHAR(20) DEFAULT 'insert' FIRST, 
   ADD revision INT(6) NOT NULL AUTO_INCREMENT AFTER action,
   ADD dt_datetime timestamp DEFAULT CURRENT_TIMESTAMP NOT NULL AFTER revision,
   ADD PRIMARY KEY (pid, revision);


CREATE TABLE plamaDB.sysEval_history LIKE plamaDB.sysEval;

ALTER TABLE plamaDB.sysEval_history MODIFY COLUMN id int(11) NOT NULL,
   DROP PRIMARY KEY, ENGINE = MyISAM, ADD action VARCHAR(20) DEFAULT 'insert' FIRST,
   ADD revision INT(6) NOT NULL AUTO_INCREMENT AFTER action,
   ADD dt_datetime timestamp DEFAULT CURRENT_TIMESTAMP NOT NULL AFTER revision,
   ADD PRIMARY KEY (id, revision);
