

var app = angular.module('partition', []);


//------------------Controller----------------------------------------------

//partitions 

app.controller('partitio', function($scope, $interval, $http){
	
	
	$interval(function(){
		$http.get("partition.php").then(function(response){
			$scope.results = response.data;
		});
	}, 2000);
});

app.controller('checkRun', function($scope, $interval, $http){
	$scope.modRun = true;
	$interval(function(){
		$http.get("runCheck.php", {timeout: 2000}).then(function(response){
			$scope.plamaRun = response.data.plamaRun;
			$scope.modRun = true;
		}, function(response){			
				$scope.modRun = false;				
		});
	}, 5000);
});


app.controller('updateModInfo', function($scope, $interval, $http){
	$interval(function(){
		$http.get("moduleInfo.php", {timeout: 2000}).then(function(response){
			$scope.modName = response.data.modName;
			$scope.modId = response.data.modId;
			$scope.hostname = response.data.hostname;
			$scope.type = response.data.type;
			$scope.state = response.data.state;
			$scope.status = "On";
		}, function(response){			
				$scope.status = "Off";			
		});
	}, 5000);	
});
