

var app = angular.module('appResPlan', []);


//------------------Controller----------------------------------------------

//Own Module
app.controller('configOwnMod', function($scope, $interval, $http){
	$interval(function(){
		$http.get("srv/configOwnMod.php").then(function(response){
			$scope.results = response.data;
		});
	}, 2000);
	
});

//partitions 

app.controller('planExecutePolicies', function($scope, $interval, $http){
	
	$scope.detail = false;
	
	$interval(function(){
		$http.get("srv/planExecutePoloicies.php").then(function(response){
			$scope.results = response.data;
		});
	}, 2000);
	
//POLICY DETAILS
	$scope.policy= function(data){
		url="srv/showPolicy.php?pid=" + data.id;
		$http.get(url).then(function(response){
			$scope.detail = true;
			$scope.policyID = response.data[0].id;
			$scope.policyName = response.data[0].name;
			$scope.policyPriority = response.data[0].priority;
			$scope.policyDescription = response.data[0].description;
		});
		
	}
	console.log($scope.detail)
});


app.controller('checkRun', function($scope, $interval, $http){
	$scope.modRun = true;
	$interval(function(){
		$http.get("srv/runCheck.php", {timeout: 2000}).then(function(response){
			$scope.plamaRun = response.data.plamaRun;
			$scope.modRun = true;
		}, function(response){			
				$scope.modRun = false;				
		});
	}, 5000);
});


app.controller('updateModInfo', function($scope, $interval, $http){
	$interval(function(){
		$http.get("../srv/moduleInfo.php", {timeout: 2000}).then(function(response){
			$scope.modName = response.data.modName;
			$scope.modId = response.data.modId;
			$scope.hostname = response.data.hostname;
			$scope.type = response.data.type;
			$scope.state = response.data.state;
			$scope.status = "On";
		}, function(response){			
				$scope.status = "Off";			
		});
	}, 5000);	
});
