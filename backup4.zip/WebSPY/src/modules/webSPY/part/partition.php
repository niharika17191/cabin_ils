<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
include '../../mdbConnect.php';


//Get pids
$pids = file('/home/diana/AAA/log/pids.log', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
//Get partition names
$i = 0;
$rows = array();
foreach($pids as $pid_num => $pid){
	$cmd = "ps -p ".$pid." -o comm=";
	$pname = shell_exec($cmd);
	if(!empty($pname)) {
		$rows[$i][0] = $pid;
		$rows[$i][1]=$pname;
		$i++;
	}
}
$json=json_encode($rows);

print $json;
?>