<?php
include 'testDBConnect.php';

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

$sql="SELECT m.ModuleId, m.Hostname, m.IP, m.MAC, m.status, t.topoName, t.topoId, t.simState, t.type FROM Demonstrator_DB.Module_DB m  LEFT JOIN Demonstrator_DB.TopoInfo t ON (m.ModuleID = t.Module_DB_ModuleID)";
$result = $conn->query($sql);

$rows = array();
while($r = mysqli_fetch_assoc($result)) {
	$rows[] = $r;
}
$json=json_encode($rows);

print $json;

?>