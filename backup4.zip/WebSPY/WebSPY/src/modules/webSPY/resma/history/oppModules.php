<!DOCTYPE html>

<?php
	include '../resMaFunctions.php';

	$pagenameShort = "OppMo";
	$pagenameLong = "Opp Module history";
	
	//Connect to module DB
	$servername = "localhost";
	$username = "root";
	$password = "jagen";
	// Create connection
	$conn = new mysqli($servername, $username, $password);

	// Check connection
	if ($conn->connect_error) {
	   	die("Connection failed: " . $conn->connect_error);
	}

	$oppMod=$_GET["oppMod"];
	$PoV=$_GET["PoV"];

?>
<html>
<head>
<meta http-equiv="refresh" content="2" >
	<style>
		table, th, td {
			border: 1px solid black;
		}
	</style>
	<title>
		<?php echo gethostname() . " - " . $pagenameShort;?>
	</title>
</head>

<body>
	
	<h1>Opp Module History</h1>
	
	<?php include '../../ownModInfo.php'; ?>

	<h3>Please Chose Parameters:<h3>
		

	<form action='oppModules.php' method='get'>
		Modul:<select name=oppMod>
			<option value='All'> All</option> 
			<?php
				$abfrage = "SELECT m.id, m.name FROM plamaDB.oppOwnGM s INNER JOIN orgDB.module m ON (s.module_id_opp =m.id)";
				$ergebnis = mysqli_query($conn, $abfrage);

				while($row = mysqli_fetch_assoc($ergebnis)) {

					if($row["name"]==$oppMod){
			
						echo "<option value=".$row['name']." selected>".$row['name']."</option>";
					}
					else{

						echo "<option value=".$row['name'].">".$row['name']."</option>";
					}
			
				}
			?>
		</select>
		Point of view:<select name=PoV>
			<?php
				if($PoV=='oppOwn'){
					echo "<option value='Both'> Both</option>";
					echo "<option value='oppOwn' selected> oppOwn</option>";
					echo "<option value='ownOpp'> ownOpp</option>";
				}
				elseif($PoV=='ownOpp'){
					echo "<option value='Both'> Both</option>";
					echo "<option value='oppOwn'> oppOwn</option>";
					echo "<option value='ownOpp' selected> ownOpp</option>";
				}
				else{
					echo "<option value='Both' selected> Both</option>";
					echo "<option value='oppOwn'> oppOwn</option>";
					echo "<option value='ownOpp'> ownOpp</option>";
				}
			?>
		</select>

		<input type='submit'>
	</form>

	<h2>Selected history</h2>

	<?php
		
		$abfrage = "SELECT * FROM plamaDB.oppMod_history";
		$ergebnis = mysqli_query($conn, $abfrage);
		$row = mysqli_fetch_assoc($ergebnis);
		$t0=strtotime($row['dt_datetime']);

		###################Angeforderte Tabelle###############################################
		if($PoV=='Both'){
			
			echo "<table>";
				echo "<tr>";
					echo "<th>&Delta;T [sec]</th><th>Time</th><th>ID</th><th>Name</th><th>Opp -> Own</th><th>Own -> Opp</th>";
				echo "</tr>";	
					
				if($oppMod=='All'){	
					$abfrage = "SELECT * FROM plamaDB.oppMod_history s INNER JOIN orgDB.module m ON (s.module_id_opp=m.id) ORDER BY s.dt_datetime ASC";
					$ergebnis = mysqli_query($conn, $abfrage);
					
					while($row = mysqli_fetch_assoc($ergebnis)) {			
							
						echo "<tr>";
						
							
							$dt= strtotime($row['dt_datetime'])-$t0;
							echo "<td>".$dt."</td>";
							echo "<td>".$row['dt_datetime']."</td>";
							echo "<td>".$row['module_id_opp']."</td>";
							echo "<td>".$row['name']."</td>";
							if($row['action']=="update ownOpp" OR $row['action']=="insert ownOpp"){
								echo "<td>".$row['oppOwnGM']."</td>";
								echo showGMCell($row['ownOppGM']);
							}
							else{
								echo showGMCell($row['oppOwnGM']);
								echo "<td>".$row['ownOppGM']."</td>";
							}
						echo"</tr>";
					}
				}#end if oppMod=All
				else{
					$abfrage = "SELECT * FROM plamaDB.oppMod_history s INNER JOIN orgDB.module m ON (s.module_id_opp=m.id) Where name='".$oppMod."'  ORDER BY s.dt_datetime ASC";
					$ergebnis = mysqli_query($conn, $abfrage);
					
					while($row = mysqli_fetch_assoc($ergebnis)) {			
							
						echo "<tr>";
						
							
							$dt= strtotime($row['dt_datetime'])-$t0;
							echo "<td>".$dt."</td>";
							echo "<td>".$row['dt_datetime']."</td>";
							echo "<td>".$row['module_id_opp']."</td>";
							echo "<td>".$row['name']."</td>";
							if($row['action']=="update ownOpp" OR $row['action']=="insert ownOpp"){
								echo "<td>".$row['oppOwnGM']."</td>";
								echo showGMCell($row['ownOppGM']);
							}
							else{
								echo showGMCell($row['oppOwnGM']);
								echo "<td>".$row['ownOppGM']."</td>";
							}
						echo"</tr>";
					}
				}#end if !oppMod=All
				
			echo "</table>";	

		}#end if both
		elseif($PoV=='oppOwn'){
			echo "<table>";
				echo "<tr>";
					echo "<th>datetime</th><th>dt[s]</th><th>module_id_opp</th><th>name</th><th>oppOwnGM</th>";
				echo "</tr>";	
					
				if($oppMod=='All'){	
					$abfrage = "SELECT * FROM plamaDB.oppMod_history s INNER JOIN orgDB.module m ON (s.module_id_opp=m.id)  ORDER BY s.dt_datetime ASC";
					$ergebnis = mysqli_query($conn, $abfrage);
					
					while($row = mysqli_fetch_assoc($ergebnis)) {			
							
						echo "<tr>";
						
							if($row['action']=="update oppOwn" OR $row['action']=="insert oppOwn"){
								
								$dt= strtotime($row['dt_datetime'])-$t0;
								echo "<td>".$dt."</td>";
								echo "<td>".$row['dt_datetime']."</td>";
								echo "<td>".$row['module_id_opp']."</td>";
								echo "<td>".$row['name']."</td>";
								echo showGMCell($row['oppOwnGM']);
							}
						echo"</tr>";
					}
				}#end if oppMod=All
				else{
					$abfrage = "SELECT * FROM plamaDB.oppMod_history s INNER JOIN orgDB.module m ON (s.module_id_opp=m.id) Where name='".$oppMod."'  ORDER BY s.dt_datetime ASC";
					$ergebnis = mysqli_query($conn, $abfrage);
					
					while($row = mysqli_fetch_assoc($ergebnis)) {			
							
						echo "<tr>";
						
							if($row['action']=="update oppOwn" OR $row['action']=="insert oppOwn"){
								
								$dt= strtotime($row['dt_datetime'])-$t0;
								echo "<td>".$dt."</td>";
								echo "<td>".$row['dt_datetime']."</td>";
								echo "<td>".$row['module_id_opp']."</td>";
								echo "<td>".$row['name']."</td>";
								echo showGMCell($row['oppOwnGM']);
							}
						echo"</tr>";
					}
				}#end if !oppMod=All
				
			echo "</table>";
		}#end if oppOwn
		if($PoV=='ownOpp'){
			
			echo "<table>";
				echo "<tr>";
					echo "<th>datetime</th><th>dt[s]</th><th>module_id_opp</th><th>name</th><th>ownOppGM</th>";
				echo "</tr>";	
					
				if($oppMod=='All'){	
					$abfrage = "SELECT * FROM plamaDB.oppMod_history s INNER JOIN orgDB.module m ON (s.module_id_opp=m.id)  ORDER BY s.dt_datetime ASC";
					$ergebnis = mysqli_query($conn, $abfrage);
					
					while($row = mysqli_fetch_assoc($ergebnis)) {			
							
						echo "<tr>";
						
							if($row['action']=="update ownOpp" OR $row['action']=="insert ownOpp"){	
								
								$dt= strtotime($row['dt_datetime'])-$t0;
								echo "<td>".$dt."</td>";
								echo "<td>".$row['dt_datetime']."</td>";
								echo "<td>".$row['module_id_opp']."</td>";
								echo "<td>".$row['name']."</td>";
								echo showGMCell($row['ownOppGM']);
							}
						echo"</tr>";
					}
				}#end if oppMod=All
				else{
					$abfrage = "SELECT * FROM plamaDB.oppMod_history s INNER JOIN orgDB.module m ON (s.module_id_opp=m.id) Where name='".$oppMod."'  ORDER BY s.dt_datetime ASC";
					$ergebnis = mysqli_query($conn, $abfrage);
					
					while($row = mysqli_fetch_assoc($ergebnis)) {			
							
						echo "<tr>";
						
							if($row['action']=="update ownOpp" OR $row['action']=="insert ownOpp"){							
								
								$dt= strtotime($row['dt_datetime'])-$t0;
								echo "<td>".$dt."</td>";
								echo "<td>".$row['dt_datetime']."</td>";
								echo "<td>".$row['module_id_opp']."</td>";
								echo "<td>".$row['name']."</td>";
								echo showGMCell($row['ownOppGM']);
							}
						echo"</tr>";
					}
				}#end if !oppMod=All
				
			echo "</table>";	

		}#end if ownOpp

	 ?>


	</br>
	</br>
	<a href="../resEval.php">Ressource Evaluation</a>
	</br>
	<a href="../../index.php">Home</a>	


</body>

</html>

