<!DOCTYPE html>

<?php
	include '../resMaFunctions.php';

	$pagenameShort = "Mapps";
	$pagenameLong = "Mapp Evaluation history";
	
	//Connect to module DB
	$servername = "localhost";
	$username = "root";
	$password = "jagen";
	// Create connection
	$conn = new mysqli($servername, $username, $password);

	// Check connection
	if ($conn->connect_error) {
	   	die("Connection failed: " . $conn->connect_error);
	}

?>

<html>
<head>
<meta http-equiv="refresh" content="2" >
	<style>
		table, th, td {
			border: 1px solid black;
		}
	</style>
	<title>
		<?php echo gethostname() . " - " . $pagenameShort;?>
	</title>
</head>

<body>
	
	<h1>Mapp Evaluation History</h1>
		
	<?php
		include '../../ownModInfo.php';

		$abfrage="SELECT * FROM plamaDB.mappEval_history";
		$ergebnis = mysqli_query($conn, $abfrage);
		$row = mysqli_fetch_assoc($ergebnis);
		$t0=strtotime($row['dt_datetime']);		

	?>


	</br>
	</br>
	
	<table>
		<tr><th>&Delta;T [sec]</th><th>Time</th><th>Role</th><th>Host</th><th>GM</th><th>QoS</th><th>M/S</th></tr>
		
		<?php
			$abfrage="SELECT p.action, p.dt_datetime, p.module_id_host, m.name, p.mappGM, p.qos, p.ms
				  FROM plamaDB.mappEval_history AS p INNER JOIN orgDB.module AS m ON m.id=p.module_id_host ORDER BY p.dt_datetime ASC;";

			$ergebnis = mysqli_query($conn, $abfrage);
					
			while($row = mysqli_fetch_assoc($ergebnis)) {			
							
				echo "<tr>";					
					
					$dt=strtotime($row["dt_datetime"])-$t0;
					echo "<td>".$dt."</td>";
					echo "<td>".$row["dt_datetime"]."</td>";
					if($row["module_id_host"]==$modId){
						echo "<td>own</td>";
					}
					else{
						echo "<td>opp</td>";
					}
					echo "<td>".$row["name"]."</td>";
					if($row["action"]=='update mappGM'){
						echo showGMCell($row["mappGM"]);
						echo "<td>".$row["qos"]."</td>";
						echo "<td>".$row["ms"]."</td>";
					}
					else if($row["action"]=="update qos"){	

						echo "<td>".$row["mappGM"]."</td>";
						echo showQoSCell($row["qos"]);
						echo "<td>".$row["ms"]."</td>";
					}
					else{
						echo "<td>".$row["mappGM"]."</td>";
						echo "<td>".$row["qos"]."</td>";
						echo showMSCell($row["ms"]);
					}
				
				echo "</tr>";
			}
		?>
	</table>

	
	</br>
	</br>
	<a href="../resEval.php">Ressource Evaluation</a>
	</br>
	<a href="../../index.php">Home</a>

</body>
</html>
