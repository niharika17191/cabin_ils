<!DOCTYPE html>

<?php
	include '../resMaFunctions.php';

	$pagenameShort = "truncate";
	$pagenameLong = "truncate history";
	
	//Connect to module DB
	$servername = "localhost";
	$username = "root";
	$password = "jagen";
	// Create connection
	$conn = new mysqli($servername, $username, $password);

	// Check connection
	if ($conn->connect_error) {
	   	die("Connection failed: " . $conn->connect_error);
	}

		
	//truncate tables
	$abfrage = "truncate table plamaDB.mappEval_history";
	$ergebnis = mysqli_query($conn, $abfrage);
	$abfrage = "truncate table plamaDB.oppMod_history";
	$ergebnis = mysqli_query($conn, $abfrage);
	$abfrage = "truncate table plamaDB.ownOwnEval_history";
	$ergebnis = mysqli_query($conn, $abfrage);
	$abfrage = "truncate table plamaDB.partitionConfig_history";
	$ergebnis = mysqli_query($conn, $abfrage);
	$abfrage = "truncate table plamaDB.xModuleConfig_history";
	$ergebnis = mysqli_query($conn, $abfrage);
	$abfrage = "truncate table plamaDB.switchConfig_history";
	$ergebnis = mysqli_query($conn, $abfrage);



?>

<html>
<head>
<meta http-equiv="refresh" content="1; URL=../resEval.php" >
	<style>
		table, th, td {
			border: 1px solid black;
		}
	</style>
	<title>
		<?php echo gethostname() . " - " . $pagenameShort;?>
	</title>
</head>

<body>
History is beeing deleted...
</body>

</html>
