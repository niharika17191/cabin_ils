<?php	
include '../../mdbConnect.php';
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
	// Get module and id name from moduleDB
	$sql = "SELECT o.name, o.id FROM orgDB.module o INNER JOIN plamaDB.ownOwnEval p ON (p.module_id = o.id)";
	$result = $conn->query($sql);

	if ($result->num_rows > 0) {
   		$rows = array();
   		while($r = mysqli_fetch_assoc($result)) {
   			$modName = $r["name"];
   			$modId = $r["id"];
   			$rows[] = $r;
   		
   		}
    	
		}
	else {
		$modName = "";
		$modId = "";
		}
	//Get hostname
	$hostname = gethostname();
	
	
	$arr = json_decode($json, true);
	$arrne['hostname'] = gethostname();
	array_push( $arr['rows'], $arrne );

	$json=json_encode($rows);
	
	
	print $json;
?>

