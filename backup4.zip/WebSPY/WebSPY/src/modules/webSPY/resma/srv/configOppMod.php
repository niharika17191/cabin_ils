<?php

include '../../mdbConnect.php';
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
	$sql = "SELECT m.name, m.id, x.blacklistState FROM plamaDB.xModuleConfig x INNER JOIN orgDB.module m ON (x.module_id = m.id) ORDER BY m.name ASC";
	$result = $conn->query($sql);
	if($result->num_rows > 0) {
		$rows = array();
		while($r = mysqli_fetch_assoc($result)) {
			$rows[] = $r;
				
		}
			
	}
	$json=json_encode($rows);
	
	print $json;
	/*if ($result->num_rows > 0) {
   	while($row = $result->fetch_assoc()) {
   		echo "<tr><td><b>" . $row["name"] . "</b></td>";
   		echo "<td>" . $row["id"] . "</td>";
   		echo showInputStateCell($row["blacklistState"]) . "</tr>";
   		}
   	}*/
?>