<?php
include '../../mdbConnect.php';
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
	$sql = "SELECT `pid`, `name`, `inputState`, `outputState`, `opmo` FROM plamaDB.partitionConfig ORDER BY `name` ASC";
	$result = $conn->query($sql);
	if($result->num_rows > 0) {
		$rows = array();
		while($r = mysqli_fetch_assoc($result)) {
			$rows[] = $r;
				
		}
			
	}
	$json=json_encode($rows);
	
	print $json;
?>