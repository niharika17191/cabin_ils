<?php
include '../../mdbConnect.php';
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
	$sql = "SELECT m.name AS mName, m.id, s.cmdId, r.name AS rName FROM plamaDB.switchConfig s INNER JOIN orgDB.module m ON (s.module_id = m.id) INNER JOIN plamaDB.routingTables r ON (s.routingTables_id = r.id) ORDER BY m.name ASC";
	$result = $conn->query($sql);
	if($result->num_rows > 0) {
		$rows = array();
		while($r = mysqli_fetch_assoc($result)) {
			$rows[] = $r;
				
		}
			
	}
	$json=json_encode($rows);
	
	print $json;
	/*if ($result->num_rows > 0) {
   	while($row = $result->fetch_assoc()) {
   		echo "<tr><td><b>" . $row["mName"] . "</b></td>";
   		echo "<td>" . $row["id"] . "</td>";
   		echo "<td>" . $row["cmdId"] . "</td>";
   		echo showRTCell($row["rName"]);   		
   		echo "</tr>";
   		}
   	}	*/
?>