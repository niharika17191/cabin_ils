<?php
include '../../mdbConnect.php';
// Get module and id name from moduleDB
$sql = "SELECT o.name, o.id FROM orgDB.module o INNER JOIN plamaDB.ownOwnEval p ON (p.module_id = o.id)";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
	$row = $result->fetch_assoc();
	$data->modName = $row["name"];
	$data->modId = $row["id"];
}
else {
	$data->modName = "";
	$data->modId = "";
}
//Get hostname
$data->hostname = gethostname();

$json=json_encode($data);

print $json;


?>