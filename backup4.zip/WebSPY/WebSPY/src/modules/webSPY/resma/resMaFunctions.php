<?php
	function showInputStateCell($is) {
		if($is === "IS_PROCESS_MSG") {
			$celltext = "<td bgcolor=\"#00FF40\">PROCESS</td>";
			}
		else if($is === "IS_DROP_MSG") {
			$celltext = "<td bgcolor=\"#FF0000\">DROP</td>"; 
			}
		return $celltext;
	}
		
	function showOutputStateCell($os){
		if($os === "OS_SEND_MSG") {
			$celltext = "<td bgcolor=\"#00FF40\">SEND</td>";
			}
		else if($os === "OS_DROP_MSG") {
			$celltext = "<td bgcolor=\"#FF0000\">DROP</td>"; 
			}
		return $celltext;
		}
		
		function showGMCell($gm){
			
	if($gm === "ON"){
		$celltext = "<td bgcolor=\"#00FF40\">ON</td>"; 		
	}
	else if($gm === "OFF.RST"){
		$celltext = "<td bgcolor=\"#999999\">OFF.RST</td>"; 		
	}
	else if($gm === "OFF.ISO"){
		$celltext = "<td bgcolor=\"#FF0000\">OFF.ISO</td>"; 		
	}
	else if($gm === "NA"){
		$celltext = "<td bgcolor=\"#EBEBEB\">n/a</td>"; 		
	}
	else if($gm === "NIL"){
		$celltext = "<td bgcolor=\"#BCBCBC\">NIL</td>"; 		
	}
	else {
		$celltext = "<td></td>";	
	}
	return $celltext;
}

function showQoSCell($qos){

	if($qos >= 0) {
		$celltext = "<td bgcolor=\"00FF40\">".$qos."</td>";
	}	
	else if($qos == -1){
		$celltext = "<td bgcolor=\"#EBEBEB\">n/a</td>";
	}
	else if($qos == -2){
		$celltext = "<td bgcolor=\"#BCBCBC\">NIL</td>"	;
	}
	else {
		$celltext = "<td></td>";	
	}	
	return $celltext;
}


function showMSCell($ms){
	if($ms === "MS_NA"){
		$celltext = "<td bgcolor=\"#EBEBEB\">n/a</td>"; 
	}
	else if($ms === "MS_NIL"){
		$celltext = "<td bgcolor=\"#BCBCBC\">NIL</td>";  
	}
	else if($ms === "MS_S"){
		$celltext = "<td bgcolor=\"#99B2FF\">S</td>";  
	}
	else if($ms === "MS_MI"){
		$celltext = "<td bgcolor=\"#5C85FF\">MI</td>";  
	}
	else if($ms === "MS_M"){
		$celltext = "<td bgcolor=\"#0000FF\">M</td>";  
	}
	else {
		$celltext = "<td></td>";	
	}	
	return $celltext;
	
}


function showModOpmo($opmo, $step){
	if($opmo === "NETPAS.ORG"){
		$celltext = "<td bgcolor=\"#33ccff\">NETPAS.ORG";	
		}
	else if($opmo === "NETPAS.INIT"){
		$celltext = "<td bgcolor=\"#cccccc\">NETPAS.INIT";	
		}
	else if($opmo === "NETPAS.MODBIT"){
		$celltext = "<td bgcolor=\"#ff8000\">NETPAS.MOD-BIT";	
		}
	else if($opmo === "NETOP.IDLE"){
		$celltext = "<td bgcolor=\"#99ff99\">NETOP.IDLE";	
		}
	else if($opmo === "NETOP.NOP"){
		$celltext = "<td bgcolor=\"#1aff1a\">NETOP.NOP";	
		}
	else if($opmo === "NETOP.MODTEST1"){
		$celltext = "<td bgcolor=\"#cc6600\">NETOP.MOD-TEST1";	
		}
	else if($opmo === "NETOP.MODTEST2"){
		$celltext = "<td bgcolor=\"#994d00\">NETOP.MOD-TEST2";	
		}
	else if($opmo === "NETOP.MAINT"){
		$celltext = "<td bgcolor=\"#cc9900\">NETOP.MAINT";	
		}
	else if($opmo === "ISO"){
		$celltext = "<td bgcolor=\"#ff0000\">ISO";	
		}
	else if($opmo === "ORG"){
		$celltext = "<td bgcolor=\"#0066ff\">ORG";	
		}
	else if($opmo === "PWR_OFF"){
		$celltext = "<td bgcolor=\"#a6a6a6\">PWR OFF";	
		}
	else if($opmo === "NA"){
		$celltext = "<td bgcolor=\"#a6a6a6\">n/a";	
		}
	else{
		$celltext = "<td bgcolor=\"#666666\">NIL";	
		}
	
	$celltext = $celltext." (".$step.")</td>";
	return $celltext;
	}
	
function showRTCell($rt){
	if($rt === "Full"){
		$celltext = "<td bgcolor=\"#EBEBEB\">Full</td><td><img src=\"img/rtFull.png\" alt=\"full\" width=\"38\" height=\"25\" /></td>";		
		}
	else if($rt === "Optimized"){
		$celltext = "<td>Optimized</td><td><img src=\"img/rtOpt.png\" alt=\"opt\" width=\"38\" height=\"25\" /></td>";		
		}	
	else if($rt === "Iso Middle"){
		$celltext = "<td bgcolor=\"#EBEBEB\">Iso Middle</td><td><img src=\"img/rtIsoMiddle.png\" alt=\"isoM\" width=\"38\" height=\"25\" /></td>";		
		}		
	return $celltext;
	}

?>