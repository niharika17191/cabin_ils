<?php
	//$plamaPid = shell_exec("ps -C PLAMA -o pid=");
	$plamaPid = 1;
	if(empty($plamaPid)) {
		echo "<html><head><meta http-equiv=\"refresh\" content=\"2\" >";
		echo "<title>". gethostname() . " - " . $pagenameShort . "</title>";
		echo "</head><body>";		
		echo "ResMa is not running<br/>";
		echo "<a href=\"../index.php\">Home</a>";
		echo "</body></html>";
		die();	
		}
?>