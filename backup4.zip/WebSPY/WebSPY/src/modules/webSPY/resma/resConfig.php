<!DOCTYPE html>

<?php
include 'resMaFunctions.php';

$pagenameShort = "ResConf";
$pagenameLong = "Ressource Configuration";
include 'runCheck.php';
include '../mdbConnect.php';
include '../modStateCheck.php';
?>

<html>
<head>
<meta http-equiv="refresh" content="2" >
<style>
table, th, td {
	border: 1px solid black;
}
</style>
<title>
<?php echo gethostname() . " - " . $pagenameShort; ?>
</title>
</head>

<body>
<h2>Ressource Configuration</h2>
<?php include '../ownModInfo.php'; ?>



<h3>Backbone Interfaces</h3>
<table>
<tr><th>ID</th><th>Name</th><th>State</th></tr>
<?php
	$sql = "SELECT i.id, i.name, c.interfaceState FROM plamaDB.interfaceConfig c INNER JOIN orgDB.interfaceAddr i ON (i.id = c.interfaceAddr_id)";
	$result = $conn->query($sql);
	if($result->num_rows > 0) {
		while($row = $result->fetch_assoc()) {
			echo "<tr><td>".$row["id"]."</td>";
			echo "<td>".$row["name"]."</td>";
			echo "<td>".$row["interfaceState"]."</td></tr>";
			}
		}
?>
</table>


<h3><a href="history/partitions.php">Partitions</a></h3>
<table>
<tr><th>PID</th><th>Name</th><th>Input State</th><th>Output State</th><th>Opmo</th></tr>
<?php
	$sql = "SELECT `pid`, `name`, `inputState`, `outputState`, `opmo` FROM plamaDB.partitionConfig ORDER BY `name` ASC";
	$result = $conn->query($sql);
	if ($result->num_rows > 0) {
   	while($row = $result->fetch_assoc()) {
   		echo "<tr><td>" . $row["pid"] . "</td>";
   		echo "<td><b>" . $row["name"] . "</b></td>";
   		echo showInputStateCell($row["inputState"]);
   		echo showOutputStateCell($row["outputState"]);
   		echo "<td>" . $row["opmo"] . "</td>";
   		echo "</tr>";
   		}
   	}
?>
</table>

<h3><a href="history/blacklist.php">Opp Modules</a></h3>
<table>
<tr><th>Name</th><th>Id</th><th>Blacklist State</th></tr>
<?php
	$sql = "SELECT m.name, m.id, x.blacklistState FROM plamaDB.xModuleConfig x INNER JOIN orgDB.module m ON (x.module_id = m.id) ORDER BY m.name ASC";
	$result = $conn->query($sql);
	if ($result->num_rows > 0) {
   	while($row = $result->fetch_assoc()) {
   		echo "<tr><td><b>" . $row["name"] . "</b></td>";
   		echo "<td>" . $row["id"] . "</td>";
   		echo showInputStateCell($row["blacklistState"]) . "</tr>";
   		}
   	}
?>
</table>

<h3><a href="history/switches.php?oppMod=All">Switches</a></h3>
<table>
<tr><th>Name</th><th>Id</th><th>C-Id</th><th colspan="2">Active Table</th></tr>
<?php
	$sql = "SELECT m.name AS mName, m.id, s.cmdId, r.name AS rName FROM plamaDB.switchConfig s INNER JOIN orgDB.module m ON (s.module_id = m.id) INNER JOIN plamaDB.routingTables r ON (s.routingTables_id = r.id) ORDER BY m.name ASC";
	$result = $conn->query($sql);
	if ($result->num_rows > 0) {
   	while($row = $result->fetch_assoc()) {
   		echo "<tr><td><b>" . $row["mName"] . "</b></td>";
   		echo "<td>" . $row["id"] . "</td>";
   		echo "<td>" . $row["cmdId"] . "</td>";
   		echo showRTCell($row["rName"]);   		
   		echo "</tr>";
   		}
   	}	
?>
</table>

<br/>
<a href="../index.php" >Home</a>
</body>
</html>

<?php
$conn->close();
?>
