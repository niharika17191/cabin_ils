/**
 * 
 */



var app = angular.module('appResEval', []);


//------------------Controller----------------------------------------------

app.controller('updateOwnOwn', function($scope, $interval, $http){
	$interval(function(){
		$http.get("srv/ownOwnEval.php").then(function(response){
			$scope.ownId = response.data[0].id;
			$scope.ownName = response.data[0].name;
			$scope.gmOwn = response.data[0].modGM;			
			$scope.gmOwnOwn = response.data[0].ownOwnGM;
			$scope.opmoOwn = response.data[0].modOpmo;
			$scope.testOwn = response.data[0].bitResult;
			$scope.ownOpmoStep = response.data[0].modOpmoStep;			
		});
	}, 2000);
	
});

app.controller('updateOppMods', function($scope, $interval, $http){
	$interval(function(){
		$http.get("srv/oppModsEval.php").then(function(response){
			$scope.oppModEval = response.data;		
		});
	}, 2000);
	
});

app.controller('checkRun', function($scope, $interval, $http){
	$scope.modRun = true;
	$interval(function(){
		$http.get("srv/runCheck.php", {timeout: 2000}).then(function(response){
			$scope.plamaRun = response.data.plamaRun;
			$scope.modRun = true;
		}, function(response){			
				$scope.modRun = false;				
		});
	}, 5000);
});

app.controller('updateApps', function($scope, $interval, $http){
	$interval(function(){
		$http.get("srv/appEval.php").then(function(response){
			$scope.apps = response.data;		
		});
	}, 2000);	
});

app.controller('updateMapps', function($scope, $interval, $http){
	$interval(function(){
		$http.get("srv/mappEval.php").then(function(response){
			$scope.mapps = response.data;		
		});
	}, 2000);	
});


app.controller('updateModInfo', function($scope, $interval, $http){
	$interval(function(){
		$http.get("../srv/moduleInfo.php", {timeout: 2000}).then(function(response){
			$scope.modName = response.data.modName;
			$scope.modId = response.data.modId;
			$scope.hostname = response.data.hostname;
			$scope.type = response.data.type;
			$scope.state = response.data.state;
			$scope.status = "On";
		}, function(response){			
				$scope.status = "Off";			
		});
	}, 5000);	
});

app.controller('updateSys', function($scope, $interval, $http){
	$interval(function(){
		$http.get("srv/sysEval.php").then(function(response){
			$scope.sys = response.data[0];
		});
	}, 2000);
});

//----------------filters----------------------------------

app.filter('removePrefix', function() {
    return function(x) {
        var txt = "";
        var i;
        
        i = x.indexOf("_");
        txt = x.slice(i+1, x.length);
        
        return txt;
    };
});

app.filter('qos_class', function(){
	return function(x){
		if(x == "-1"){
			return "qos_na";
		}
		return "qos_av";
	};
});

app.filter('qos_text', function(){
	return function(x){
		if(x == "-1"){
			return "NA";
		}
		return x;
	};
});