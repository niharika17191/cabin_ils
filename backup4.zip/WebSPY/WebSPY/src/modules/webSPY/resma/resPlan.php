<!DOCTYPE html>

<?php
include 'resMaFunctions.php';

$pagenameShort = "ResPlan";
$pagenameLong = "Ressource Planning";
include 'runCheck.php';
include '../mdbConnect.php';
include '../modStateCheck.php';
?>


<html>
<head>
<meta http-equiv="refresh" content="2" >
<style>
table, th, td {
	border: 1px solid black;
}
</style>
<title>
<?php echo gethostname() . " - " . $pagenameShort; ?>
</title>
</head>
<body>
<h2>Ressource Planning</h2>
<?php include '../ownModInfo.php'; ?>

<h3>Executed Policies</h3>

<table>
<tr>
<th rowspan="2">&Delta;T<br/>[sec]</th><th rowspan="2">time<br/>[hh:mm:ss]</th><th colspan="3">policy</th>
</tr>
<tr>
<th>id</th><th>name</th><th>parameters</th>
</tr>

<?php
$sql = "SELECT l.execTime, p.id, p.name, l.params FROM plamaDB.reconfigPolicies p INNER JOIN plamaDB.policyLog l ON p.id = l.reconfigPolicies_id ORDER BY l.execTime ASC";
$result = $conn->query($sql);	
if ($result->num_rows > 0) {
	while($row = $result->fetch_assoc()) {
		if(empty($t0)){
			$t0 = $row["execTime"];			
			}		
		$execTime = $row["execTime"];	
		$execTimeStr = date("H:i:s", $execTime);
		$dt = round($execTime - $t0, 3);		
		echo "<tr><td>".$dt."</td><td>".$execTimeStr."</td>";
		echo "<td><a href=\"showPolicy.php?pid=".$row["id"]."\">".$row["id"]."</a></td>";
		echo "<td>".$row["name"]."</td><td>".$row["params"]."</td></tr>"; 
	} 
}
?>

</table>

<br /><a href="../index.php">Home</a>
</body>
</html>

<?php
$conn->close();
?>

