<!DOCTYPE html>

<?php
$hostname = gethostname();
?>

<html>
<head>
<title>
<?php echo $hostname.": WebSPY"; ?>
</title>
</head>

<body>
<h2>Web SPY</h2>

Hostname: <?php echo $hostname; ?>
 
<h3>Pages</h3>

<h4>Organisation</h4>
<ul>
<li><a href="lorg/lorgStatus.php" >LORG Status</a></li>
</ul>


<h4>Platform Supervisor</h4>
<ul>
<li><a href="resma/resEval.html">Ressource Evaluation</a></li>
<li><a href="resma/resPlan.php">Ressource Planning</a></li>
<li><a href="resma/resConfig.php">Ressource Configuration</a></li>
<li>System Model</li>
<li>Messaging</li>
</ul>

<h4>Partitioning</h4>
<ul>
<li><a href="part/index.php">Partition Table</a></li>
</ul>

<h4>Testing</h4>
<ul>
<li><a href="stimulation/chooseStimulation.php" >Failure Stimulation</li>
</ul>


<br><br>
<a href="http://192.168.1.180/webSPY" >Main</a>

</body>

</html>