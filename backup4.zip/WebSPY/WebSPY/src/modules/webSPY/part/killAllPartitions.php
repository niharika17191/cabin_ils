<!DOCTYPE html>

<?php
$out=shell_exec("sudo /home/diana/AAA/killall.sh");
?>

<html>

<body>
Output of script: <br />
<?php echo $out; ?> <br />

<a href="index.php">Back</a>

</body>

</html>



