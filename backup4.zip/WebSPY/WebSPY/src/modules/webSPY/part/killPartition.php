<!DOCTYPE html>

<html>

<body>
<?php
$pid = $_GET["pid"];
$cmd = "sudo kill -KILL ".$pid;
shell_exec($cmd);
echo "Killed partition ".$pid;
?>
<br />
<a href="index.php">Back</a>
</body>
</html>