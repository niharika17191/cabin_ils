<?php
$state = $_GET["state"];
if(empty($state)){
	die();
}
$sock = socket_create(AF_INET, SOCK_DGRAM, SOL_UDP);
$len = strlen($state);
socket_sendto($sock, $state, $len, 0, '127.0.0.1', 60001);
socket_close($sock);
?>