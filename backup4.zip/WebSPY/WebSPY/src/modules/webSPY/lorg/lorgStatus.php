<!DOCTYPE html>

<?php
$pagenameShort = "LORGStat";
$pagenameLong = "LORG Status";
include '../mdbConnect.php';

$lorgPid = shell_exec("ps -C LORG -o pid=");
//$lorgPid = 1;

if(!empty($_POST["restartLORG"])) {
	echo "Restart LORG";
	shell_exec("sudo service lorg restart");
	}

?>





<html>
<head>
<meta http-equiv="refresh" content="2" >
<style>
table, th, td {
	border: 1px solid black;
}
</style>
<title>
<?php echo gethostname() . " - " . $pagenameShort; ?>
</title>
</head>
<body>
<h2>LORG Status</h2>
<?php include '../ownModInfo.php'; ?>

<h3>LORG Control</h3>

<table>
<tr><td><b>LORG Process</b></td>
<?php
if(empty($lorgPid)) {
	echo "<td bgcolor=\"#FF0000\">NOT RUNNING</td>";	
	}
else {
	echo "<td bgcolor=\"#00FF40\">RUNNING</td>";
	}
?>
</tr>
</table>
<br>
<form action="lorgStatus.php" method="POST">
<button id="restartLORG" name="restartLORG" value="restart">(Re)Start LORG</button>
</form>

<h3>LORG Sequence</h3>

<a href="lorgLog.php" >Detailed Log</a><br><br>

<table>
<tr><th>Nr</th><th>Phase</th><th>Result</th></tr>


<?php
$lorglog = file("/home/diana/AAA/log/lorg.log");
foreach($lorglog as $i => $line){
	if (preg_match('/LORG-Phase ([0-9]*) is \'(.*)\'/' , $line, $matches)){
		$nr = $matches[1];
		$phase = $matches[2];
		$res = "";		
		}
	else if(preg_match('/LORG service of phase \'(.*)\' failed/' , $line, $matches)){
		$res = "<td bgcolor=\"#FF0000\">FAIL</td>";			
		}
	else if(preg_match('/Phase \'(.*)\' completed successfully/' , $line, $matches)){
		$res = "<td bgcolor=\"#00FF40\">OK</td>";			
		}
	else if(preg_match('/ORG sequence was aborted by ZORG/' , $line, $matches)){
		$res = "<td bgcolor=\"#FF0000\">ABORT</td>";			
		}
	if(!empty($res)) {
		echo "<tr>";
		echo "<td>".$nr."</td>";
		echo "<td>".$phase."</td>";
		echo $res;
		echo "</tr>";
		$res="";
		$nr="";
		}
	}
if(!empty($nr)) {
		echo "<tr>";
		echo "<td>".$nr."</td>";
		echo "<td>".$phase."</td>";
		echo "<td bgcolor=\"#BCBCBC\">RUN</td>";
		echo "</tr>";		
		}

?>

</table>





<br /><a href="../index.php">Home</a>
</body>
</html>

<?php
$conn->close();
?>