<?php


function getParam($c, $name) {
	$val = "0";
	$sql="SELECT ".$name." FROM moduleStateSimulation.moduleParams WHERE id=1";
	$result = $c->query($sql);
	if($result->num_rows > 0) {
		$row = $result->fetch_assoc();
    	$val = $row[$name];
		}
	return $val;
	}


function getStateRaw($c){
	$sql="SELECT state FROM moduleStateSimulation.moduleState WHERE id=1";
	$result = $c->query($sql);
	if($result->num_rows > 0) {
		$row = $result->fetch_assoc();
    	$val = $row["state"];
		}
	else {
		$val="MST_NIL";
		}
	return $val;
	} 
	
	
function getFormatedState($c) {	
	$val = getStateRaw($c);	
	$ret="<td></td>";
	switch($val) {		
		case "MST_NIL":
			$ret = "<td bgcolor=\"#CCCCCC\">NIL</td>";
			break;
		case "MST_COR_NOT_POWERED":
			$ret = "<td bgcolor=\"#999999\">COR.NOT_POWERED</td>";
			break;
		case "MST_COR_PWR_INIT":
			$ret = "<td bgcolor=\"#b3ff99\">COR.PWR.INIT</td>";
			break;
		case "MST_COR_PWR_NOP":
			$ret = "<td bgcolor=\"#40ff00\">COR.PWR.NOP</td>";
			break;
		case "MST_COR_PWR_BIT":
			$ret = "<td bgcolor=\"#33ccff\">COR.PWR.BIT</td>";
			break;
		case "MST_FAILED":
			$ret = "<td bgcolor=\"#ff3300\">FAILED</td>";
			break;
	}
		return $ret;		
	}
	

	


?>