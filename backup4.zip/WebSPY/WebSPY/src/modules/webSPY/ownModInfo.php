<?php	
	// Get module and id name from moduleDB
	$sql = "SELECT o.name, o.id FROM orgDB.module o INNER JOIN plamaDB.ownOwnEval p ON (p.module_id = o.id)";
	$result = $conn->query($sql);

	if ($result->num_rows > 0) {
   	$row = $result->fetch_assoc();
    	$modName = $row["name"];
    	$modId = $row["id"];
		}
	else {
		$modName = "";
		$modId = "";
		}
	//Get hostname
	$hostname = gethostname();
	
	//Display information
	echo "<h3>Module Information</h3>";
	echo "Host Name: " . $hostname . "<br/>";	
	echo "Module Name: <b>" . $modName . "</b><br/>";
	echo "Module Id: <b>" . $modId . "</b><br/>";
?>