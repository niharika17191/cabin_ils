<!DOCTYPE html>

<?php

$pagenameShort = "SysTopo";
$pagenameLong = "System Topology";

if(!empty($_GET["detailLevel"])) {
	$dl = $_GET["detailLevel"];
	}
else {
	$dl = "-SA";
	}


$cmd = "sudo /home/diana/topo/TopoVisualization ".$dl." -png";
shell_exec($cmd);
?>

<html>
<head>
<?php
if(!empty($_GET["reload"])){
	echo "<meta http-equiv=\"refresh\" content=\"10\">";	
	}
?>



<style>
table, th, td {
	border: 1px solid black;
}
</style>
<title>
<?php echo gethostname() . " - " . $pagenameShort; ?>
</title>
</head>




<body>
<h2>System Topology</h2>

<form action="systemTopology.php" method="GET">
Detail Level:
<select name="detailLevel">
<option value="-S" <?php if($dl == "-S"){echo "selected";}?>>Modules only</option>
<option value="-SA" <?php if($dl == "-SA"){echo "selected";}?>>Modules & Aggregats</option>
<option value="-AP" <?php if($dl == "-AP"){echo "selected";}?>>Partitions & Aggregats</option>
<option value="-I" <?php if($dl == "-I"){echo "selected";}?>>Interfaces</option>
<option value="-IA" <?php if($dl == "-IA"){echo "selected";}?>>Interfaces & Addresses</option>
</select>
<input type="checkbox" name="reload" value="auto"
<?php
if(!empty($_GET["reload"])){
	echo " checked";	
	}
?>
> Auto Refresh </input>
<button name="cdl" value="cdl">Update View</button>

</form>


<img src="SystemTopology.png" alt="SystemTopology" width="100%" height="auto" />

</br>
<a href="../index.php">Home</a>
</body>
</html>

