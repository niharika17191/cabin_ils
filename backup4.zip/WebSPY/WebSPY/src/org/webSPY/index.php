<!DOCTYPE html>

<?php
$hostname = gethostname();
?>

<html>
<head>
<title>
<?php echo $hostname.": WebSPY"; ?>
</title>
</head>

<body>
<h2>Web SPY</h2>

Hostname: <?php echo $hostname; ?>
 
<h3>Pages</h3>

<h4>Integration</h4>
<ul>
<li><a href="sysmod/systemLayout.php">System Layout</a></li>
<li><a href="orgctl/zorgControl.php">ZORG Control</a></li>
</ul>

<h4>Validation</h4>
<ul>
<li><a href="sysmod/systemTopology.php">System Topology</a></li>
</ul>

<br><br>
<a href="http://192.168.1.180/webSPY" >Main</a>

</body>

</html>