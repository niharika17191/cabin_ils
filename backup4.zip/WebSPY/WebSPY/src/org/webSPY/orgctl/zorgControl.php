<!DOCTYPE html>

<?php

$pagenameShort = "ZorgCtl";
$pagenameLong = "ZORG Control";

$zorgPid = shell_exec("ps -C ZORG -o pid=");
//$zorgPid = 1;

if(!empty($_POST["startZORG"])) {
	$cmd = "sudo /home/diana/ORG/zorgDaemon.sh";
	$res = shell_exec($cmd);
	echo $res;
	}
else if(!empty($_POST["stopZORG"])) {
	$cmd = "sudo kill -KILL ".$zorgPid;
	shell_exec($cmd);
	echo $cmd;
	}
else if(!empty($_POST["resumeORG"])) {
	$cmd = "sudo kill -USR1 ".$zorgPid;
	shell_exec($cmd);
	echo $cmd;
	}

?>

<html>
<head>
<meta http-equiv="refresh" content="2" >
<style>
table, th, td {
	border: 1px solid black;
}
</style>
<title>
<?php echo gethostname() . " - " . $pagenameShort; ?>
</title>
</head>

<body>
<h2>ZORG Control</h2>

<h3>LORG Control</h3>

<form action="modulesToORG.php" method="POST">
<button name="modToORG" value="modToORG">Modules to ORG</button>
</form>

<h3>ZORG Control</h3>

<table>
<tr><td><b>ZORG Process</b></td>
<?php
if(empty($zorgPid)) {
	echo "<td bgcolor=\"#FF0000\">NOT RUNNING</td>";	
	}
else {
	echo "<td bgcolor=\"#00FF40\">RUNNING</td>";
	}
?>
</tr>
</table>
<br>
<form action="zorgControl.php" method="POST">
<?php
if(empty($zorgPid)) {
	echo "<button name=\"startZORG\" value=\"startZORG\"><b>Start ORG-Phase</b></button>";
	}
else {
	echo "<button name=\"stopZORG\" value=\"stopZORG\">Stop ORG-Phase</button>";
	}
?>
</form>


<h3>ZORG Sequence</h3>

<a href="zorgLog.php" >Detailed Log</a><br><br>

<table>
<tr><th>Nr</th><th>Phase</th><th>Result</th></tr>


<?php
$zorglog = file("/home/diana/ORG/log/zorg.log");
foreach($zorglog as $i => $line){
	if (preg_match('/ZORG-Phase ([0-9]*) is \'(.*)\'/' , $line, $matches)){
		$nr = $matches[1];
		$phase = $matches[2];
		$res = "";	
		$wait=FALSE;	
		}
	else if(preg_match('/ZORG service of phase \'(.*)\' failed/' , $line, $matches)){
		$res = "<td bgcolor=\"#FF0000\">FAIL</td>";			
		}
	else if(preg_match('/Phase \'(.*)\' completed successfully/' , $line, $matches)){
		$res = "<td bgcolor=\"#00FF40\">OK</td>";			
		}
	else if(preg_match('/ORG sequence was aborted by ZORG/' , $line, $matches)){
		$res = "<td bgcolor=\"#FF0000\">ABORT</td>";			
		}
	else if(preg_match('/Press ENTER to continue with next phase/' , $line, $matches)){					
		$wait=TRUE;
		}
		
	else if(preg_match('/([0-9]*) member(s) failed during phase/' , $line, $matches)){					
		$res = "<td bgcolor=\"#FF0000\">FAIL</td>";
		}
	if(!empty($res)) {
		echo "<tr>";
		echo "<td>".$nr."</td>";
		echo "<td>".$phase."</td>";
		echo $res;
		echo "</tr>";
		$res="";
		$nr="";
		}
	}
if(!empty($nr)) {
		echo "<tr>";
		echo "<td>".$nr."</td>";
		echo "<td>".$phase."</td>";
		if($wait == TRUE) {
			echo "<td bgcolor=\"#BCBCBC\">WAIT</td>";
			}
		else {
			echo "<td bgcolor=\"#BCBCBC\">RUN</td>";
			}
		echo "</tr>";		
		}


?>

</table>
</br>
<form action="zorgControl.php" method="POST">
<?php
if($wait == TRUE) {
	echo "<button name=\"resumeORG\" value=\"resumeORG\">Resume</button>";  
	}
?>
</form>




</br>
<a href="../index.php">Home</a>
</body>
</html>