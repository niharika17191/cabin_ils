<?php
	function showSwitchState($ss) {
		
		if($ss == "DYNAMIC ROUTING") {
			$celltext = "<td  bgcolor=\"#00CCFF\"><b>".$ss."</b></td>";
			}
		else if($ss == "STATIC.RESTORE") {
			$celltext = "<td  bgcolor=\"#EBEBEB\"><b>".$ss."</b></td>";
			}
		else if($ss == "STATIC.RECONFIGURE") {
			$celltext = "<td  bgcolor=\"#999999\"><b>".$ss."</b></td>";
			}
		else if($ss == "STATIC.ACTIVE") {
			$celltext = "<td  bgcolor=\"#00FF40\"><b>".$ss."</b></td>";
			}
		else {
			$celltext = "<td >-</td>";
			}
			
		return $celltext;
	}
	
	function showRTCell($rt){
	if($rt == "full"){
		$celltext = "<td bgcolor=\"#0099CC\"><b>Full</b></td></tr><tr><td><img src=\"img/rtFull.png\" alt=\"full\" width=\"80\" height=\"68\" /></td>";		
		}
	else if($rt == "optimized"){
		$celltext = "<td><b>Optimized</b></td></tr><tr><td><img src=\"img/rtOpt.png\" alt=\"opt\" width=\"80\" height=\"68\" /></td>";		
		}	
	else if($rt == "isoMiddle"){
		$celltext = "<td bgcolor=\"#FF9900\"><b>Iso Middle</b></td></tr><tr><td><img src=\"img/rtIsoMiddle.png\" alt=\"isoM\" width=\"80\" height=\"68\" /></td>";		
		}	
	else {
		$celltext = "<td >".$rt."</td></tr><tr><td></td>";
		}	
	return $celltext;
	}
	
?>




<?php
$xmlStr = file_get_contents("switches/state.xml");
$xml = new SimpleXMLElement($xmlStr);

$state = $xml->state;
$tablename = $xml->activeTable;
$cmdId = $xml->cmdId;
$hostname = gethostname();
?>




<html>
<head>
<title>Switch State</title>
<meta http-equiv="refresh" content="2" >
<style>
table, th, td {
	border: 1px solid black;
}
</style>
</head>


<body>

<h2>Switch State</h2>

<?php echo "Hostname: " . $hostname . "<br/><br/>";?>

<table>
<tr>
<td>State</td>
<?php echo showSwitchState($state); ?> 
</tr>
<tr>
<td>Command Id</td>
<td> <?php echo "<b>" . $cmdId . "</b>"; ?> </td>
</tr>
<?php
if($state == "DYNAMIC ROUTING") {
	echo "</table>";
	}
else {
	echo "<tr><td rowspan=\"2\">Active Table</td>";
	echo showRTCell($tablename);
	echo "</tr></table>";
	}	
?>
<br/>
<a href="index.php" >Home</a>

</body>


</html>