DROP TRIGGER IF EXISTS plamaDB.mappEval_data__ai;
DROP TRIGGER IF EXISTS plamaDB.mappEval_data__au;

DROP TRIGGER IF EXISTS plamaDB.oppOwnGM_data__ai;
DROP TRIGGER IF EXISTS plamaDB.oppOwnGM_data__au;

DROP TRIGGER IF EXISTS plamaDB.ownOppGM_data__ai;
DROP TRIGGER IF EXISTS plamaDB.ownOppGM_data__au;

DROP TRIGGER IF EXISTS plamaDB.ownOwnEval_data__ai;
DROP TRIGGER IF EXISTS plamaDB.ownOwnEval_data__au;

DROP TRIGGER IF EXISTS plamaDB.switchConfig_data__ai;
DROP TRIGGER IF EXISTS plamaDB.switchConfig_data__au;

DROP TRIGGER IF EXISTS plamaDB.xModuleConfig_data__ai;
DROP TRIGGER IF EXISTS plamaDB.xModuleConfig_data__au;

DROP TRIGGER IF EXISTS plamaDB.partitionConfig_data__ai;
DROP TRIGGER IF EXISTS plamaDB.partitionConfig_data__au;


DROP TRIGGER IF EXISTS plamaDB.partitionConfig_data__ai;
DROP TRIGGER IF EXISTS plamaDB.partitionConfig_data__au;




CREATE TRIGGER plamaDB.mappEval_data__ai AFTER INSERT ON plamaDB.mappEval FOR EACH ROW
    INSERT INTO plamaDB.mappEval_history SELECT 'insert', NULL, NOW(), d.* 
    FROM plamaDB.mappEval AS d WHERE d.module_id_host = NEW.module_id_host;
	
DELIMITER //

CREATE TRIGGER plamaDB.mappEval_data__au
	AFTER UPDATE ON plamaDB.mappEval FOR EACH ROW
	BEGIN
		IF NEW.mappGM <> OLD.mappGM THEN 
			INSERT INTO plamaDB.mappEval_history SELECT 'update mappGM', NULL, NOW(), d.* FROM plamaDB.mappEval AS d WHERE d.module_id_host = NEW.module_id_host ;
		END IF;
		IF NEW.qos <> OLD.qos THEN
			INSERT INTO plamaDB.mappEval_history  SELECT 'update qos', NULL, NOW(), d.* FROM plamaDB.mappEval AS d WHERE d.module_id_host = NEW.module_id_host;
		END IF;
		IF NEW.ms <> OLD.ms THEN		
			INSERT INTO plamaDB.mappEval_history SELECT 'update ms', NULL, NOW(), d.* FROM plamaDB.mappEval AS d WHERE d.module_id_host = NEW.module_id_host;
		END IF;
	END;


CREATE TRIGGER plamaDB.oppOwnGM_data__ai AFTER INSERT ON plamaDB.oppOwnGM FOR EACH ROW
    	INSERT INTO plamaDB.oppMod_history SELECT 'insert oppOwn', NULL, NOW(), plamaDB.oppOwnGM.module_id_opp,
    	plamaDB.oppOwnGM.oppOwnGM,  plamaDB.ownOppGM.ownOppGM 
    	FROM plamaDB.oppOwnGM INNER JOIN plamaDB.ownOppGM
    	ON plamaDB.oppOwnGM.module_id_opp=plamaDB.ownOppGM.module_id_opp
    	WHERE plamaDB.oppOwnGM.module_id_opp = NEW.module_id_opp;

CREATE TRIGGER plamaDB.oppOwnGM_data__au AFTER UPDATE ON plamaDB.oppOwnGM FOR EACH ROW
    INSERT INTO plamaDB.oppMod_history SELECT 'update oppOwn', NULL, NOW(), plamaDB.oppOwnGM.module_id_opp,
    plamaDB.oppOwnGM.oppOwnGM,  plamaDB.ownOppGM.ownOppGM 
    FROM plamaDB.oppOwnGM INNER JOIN plamaDB.ownOppGM
    ON plamaDB.oppOwnGM.module_id_opp=plamaDB.ownOppGM.module_id_opp
    WHERE plamaDB.oppOwnGM.module_id_opp = NEW.module_id_opp; 
    
    
CREATE TRIGGER plamaDB.ownOppGM_data__ai AFTER INSERT ON plamaDB.ownOppGM FOR EACH ROW
    INSERT INTO plamaDB.oppMod_history SELECT 'insert ownOpp', NULL, NOW(), plamaDB.oppOwnGM.module_id_opp,
    plamaDB.oppOwnGM.oppOwnGM,  plamaDB.ownOppGM.ownOppGM 
    FROM plamaDB.oppOwnGM INNER JOIN plamaDB.ownOppGM
    ON plamaDB.oppOwnGM.module_id_opp=plamaDB.ownOppGM.module_id_opp
    WHERE plamaDB.oppOwnGM.module_id_opp = NEW.module_id_opp;

CREATE TRIGGER plamaDB.ownOppGM_data__au AFTER UPDATE ON plamaDB.ownOppGM FOR EACH ROW
    INSERT INTO plamaDB.oppMod_history SELECT 'update ownOpp', NULL, NOW(), plamaDB.oppOwnGM.module_id_opp,
    plamaDB.oppOwnGM.oppOwnGM,  plamaDB.ownOppGM.ownOppGM 
    FROM plamaDB.oppOwnGM INNER JOIN plamaDB.ownOppGM
    ON plamaDB.oppOwnGM.module_id_opp=plamaDB.ownOppGM.module_id_opp
    WHERE plamaDB.oppOwnGM.module_id_opp = NEW.module_id_opp;
    

CREATE TRIGGER plamaDB.ownOwnEval_data__ai AFTER INSERT ON plamaDB.ownOwnEval
	FOR EACH ROW
	
    INSERT INTO plamaDB.ownOwnEval_history SELECT 'insert', NULL, NOW(), d.* 
    FROM plamaDB.ownOwnEval AS d WHERE d.module_id = NEW.module_id;

CREATE TRIGGER plamaDB.ownOwnEval_data__au AFTER UPDATE ON plamaDB.ownOwnEval
	FOR EACH ROW
	BEGIN
		IF NEW.modGM <> OLD.modGM THEN
    			INSERT INTO plamaDB.ownOwnEval_history SELECT 'update modGM', NULL, NOW(), d.* 
			FROM plamaDB.ownOwnEval AS d WHERE d.module_id = NEW.module_id;
		END IF;
		IF NEW.ownOwnGM <> OLD.ownOwnGM THEN
			INSERT INTO plamaDB.ownOwnEval_history SELECT 'update ownGM', NULL, NOW(), d.* 
			FROM plamaDB.ownOwnEval AS d WHERE d.module_id = NEW.module_id;
		END IF;
		IF NEW.modOpmo <> OLD.modOpmo THEN
			INSERT INTO plamaDB.ownOwnEval_history SELECT 'update Opmo', NULL, NOW(), d.* 
			FROM plamaDB.ownOwnEval AS d WHERE d.module_id = NEW.module_id;
		END IF;
		IF NEW.modOpmoStep <> OLD.modOpmoStep THEN
			INSERT INTO plamaDB.ownOwnEval_history SELECT 'update Step', NULL, NOW(), d.* 
			FROM plamaDB.ownOwnEval AS d WHERE d.module_id = NEW.module_id;
		END IF;
		IF NEW.bitResult <> OLD.bitResult THEN
			INSERT INTO plamaDB.ownOwnEval_history SELECT 'update bit', NULL, NOW(), d.* 
			FROM plamaDB.ownOwnEval AS d WHERE d.module_id = NEW.module_id;
		END IF;
	END;    
    

CREATE TRIGGER plamaDB.switchConfig_data__ai AFTER INSERT ON plamaDB.switchConfig FOR EACH ROW
    INSERT INTO plamaDB.switchConfig_history SELECT 'insert', NULL, NOW(), d.* 
    FROM plamaDB.switchConfig AS d WHERE d.module_id = NEW.module_id;

CREATE TRIGGER plamaDB.switchConfig_data__au AFTER UPDATE ON plamaDB.switchConfig FOR EACH ROW
    INSERT INTO plamaDB.switchConfig_history SELECT 'update', NULL, NOW(), d.*
    FROM plamaDB.switchConfig AS d WHERE d.module_id = NEW.module_id;
    
    
CREATE TRIGGER plamaDB.xModuleConfig_data__ai AFTER INSERT ON plamaDB.xModuleConfig FOR EACH ROW
    INSERT INTO plamaDB.xModuleConfig_history SELECT 'insert', NULL, NOW(), d.* 
    FROM plamaDB.xModuleConfig AS d WHERE d.module_id = NEW.module_id;

CREATE TRIGGER plamaDB.xModuleConfig_data__au AFTER UPDATE ON plamaDB.xModuleConfig FOR EACH ROW
    INSERT INTO plamaDB.xModuleConfig_history SELECT 'update', NULL, NOW(), d.*
    FROM plamaDB.xModuleConfig AS d WHERE d.module_id = NEW.module_id;


CREATE TRIGGER plamaDB.partitionConfig_data__ai AFTER INSERT ON plamaDB.partitionConfig FOR EACH ROW
    INSERT INTO plamaDB.partitionConfig_history SELECT 'insert', NULL, NOW(), d.* 
    FROM plamaDB.partitionConfig AS d WHERE d.pid = NEW.pid;

CREATE TRIGGER plamaDB.partitionConfig_data__au 
	AFTER UPDATE ON plamaDB.partitionConfig FOR EACH ROW
	BEGIN
		IF NEW.inputState <> OLD.inputState THEN
    			INSERT INTO plamaDB.partitionConfig_history SELECT 'update inputState', NULL, NOW(), d.*
    			FROM plamaDB.partitionConfig AS d WHERE d.pid = NEW.pid;
		END IF;
		IF NEW.outputState <> OLD.outputState THEN
             		INSERT INTO plamaDB.partitionConfig_history SELECT 'update outputState', NULL, NOW(), d.*
    			FROM plamaDB.partitionConfig AS d WHERE d.pid = NEW.pid;
		END IF;
		IF NEW.opmo <> OLD.opmo THEN
			INSERT INTO plamaDB.partitionConfig_history SELECT 'update opmo', NULL, NOW(), d.*
			FROM plamaDB.partitionConfig AS d WHERE d.pid = NEW.pid;
		END IF;
	END;

CREATE TRIGGER plamaDB.sysEval_data__ai AFTER INSERT ON plamaDB.sysEval FOR EACH ROW
    INSERT INTO plamaDB.sysEval_history SELECT 'insert', NULL, NOW(), d.*
    FROM plamaDB.sysEval AS d WHERE d.id = NEW.id;

CREATE TRIGGER plamaDB.sysEval_data__au AFTER UPDATE ON plamaDB.sysEval FOR EACH ROW
    INSERT INTO plamaDB.sysEval_history SELECT 'update', NULL, NOW(), d.*
    FROM plamaDB.sysEval AS d WHERE d.id = NEW.id;
